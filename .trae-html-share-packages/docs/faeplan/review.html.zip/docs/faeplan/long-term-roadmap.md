# FAE Agent / Engine 长期发展规划

> 审查日期：2026-10-30  
> 代码基线：`3629748d91ed978723f001c35051f22886b42b42`，审查开始时工作区无未提交改动。  
> 范围：`crates/fae-agent`、`crates/fae-engine` 的完整源码与包依赖；README 和 examples 用于理解使用方式。  
> 规划跨度：未来 12–18 个月，以阶段验收推进；时间窗口是建议顺序，不是交付承诺。  
> 文档性质：代码审查支撑的技术路线。文中的拟议接口、指标和场景均为规划，不代表现有实现。

## 1. 定位与优先级

FAE 最值得发展的定位是：**面向本地开发与业务自动化的 Rust Agent 执行内核，支持可控的长任务、可恢复的工作流和可验证的工具协作。** 当前优势是计划与执行分离、可组合运行时、结构化工作流以及 Agent/Workflow 的工具化调用。下一阶段应优先让已有能力在失败、并发、取消和重启条件下成立，再增加新的编排模式。

优先顺序如下：

1. 修复影响正确性和生命周期的具体缺陷，建立可重复的离线验证。
2. 统一任务终态、取消、错误分类、资源预算和工具控制边界。
3. 建立执行快照、暂停/恢复、审批和副作用记录。
4. 用事件追踪与评测支撑模型适配、上下文管理和协作策略迭代。
5. 在这些基础上交付两类完整场景：可恢复的编码助手、可审批的业务工作流。

多 Agent 角色数量、更多提示词模板、可视化编辑器和大量连接器不应成为近期的主要投入。它们的价值需要由任务完成质量、可恢复性和维护成本证明。

LangGraph 的持久执行、OpenAI Agents SDK 的审批与追踪、Pydantic AI 的持久执行与类型化输出共同说明：执行控制和质量验证是值得借鉴的工程方向。[cite:1](#source-1)[cite:5](#source-5)[cite:4](#source-4) 这是基于官方文档的跨框架归纳，不是市场份额、性能或可靠性排名。

## 2. 当前基础与能力边界

### 2.1 架构基础

```mermaid
flowchart TD
    E["Engine：构建并启动 Plan"] --> P["Plan：init / next / abort"]
    P --> PR["PlanRuntime：任务分发与结果回调"]
    PR --> RT["EngineRuntime：运行时路由与 hook 组合"]
    RT --> M["ModelRuntime"]
    RT --> T["ToolsRuntime / MCP"]
    RT --> S["Session / Memory / Skill"]
    RT --> W["子 Plan / Workflow"]
    M --> PR
    T --> PR
    W --> PR
    P --> UI["SessionEvent：对外展示执行过程"]
```

`fae-agent` 定义协议、计划状态机和 hook；`fae-engine` 提供调度、存储、模型、MCP 和工具实现。这个分工应保留。规划中的状态存储、审批和遥测不能把具体数据库、容器或某一家模型平台依赖反向引入协议层。

| 能力 | 当前判断 | 代码依据与规划含义 |
| --- | --- | --- |
| 计划与运行时分离 | 已实现 | [Plan](../../crates/fae-agent/src/plan/plan_define.rs#L5-L22)、[Runtime](../../crates/fae-agent/src/runtime/runtime.rs)：允许独立演进执行控制 |
| 五类 hook | 已实现 | [hook 模块](../../crates/fae-agent/src/hook/mod.rs)、[SingleAgentHook](../../crates/fae-agent/src/hook/single_agent_hook.rs#L35-L106)：已有 transform 风格回调，应先明确契约再扩展 |
| 单 Agent 工具循环与保护 | 已实现部分控制 | [single_agent.rs](../../crates/fae-agent/src/plan/single_agent.rs#L99-L127)：有工具迭代上限、一次空输出重试、上下文压缩阈值 |
| 工作流分支、并行、汇合与循环 | 已实现，但组合有限 | [workflow/plan.rs](../../crates/fae-agent/src/workflow/plan.rs)：包含一般图与 DAG 两条执行路径；循环图目前不能混用 fan-out/多输入 join，见 [builder.rs](../../crates/fae-agent/src/workflow/builder.rs#L280-L287) |
| Agent / Workflow 工具化委派 | 已实现，身份传播有缺口 | [agent 工具](../../crates/fae-engine/src/tools/agent.rs)、[workflow 工具](../../crates/fae-engine/src/tools/workflow.rs)：优先修复 Workflow Tool 路径的用户继承，再增强父子资源控制 |
| 会话、用户记忆、todo 持久化 | 已实现基础存储，一致性有限 | [session_runtime.rs](../../crates/fae-engine/src/engine_rt/session_runtime.rs)、[memory_runtime.rs](../../crates/fae-engine/src/engine_rt/memory_runtime.rs)、[todo.rs](../../crates/fae-engine/src/tools/todo.rs)：需完善批次原子性、读写同步与写失败恢复；不是执行恢复协议 |
| Skill 与 MCP | 已实现基础接入 | [skill_runtime.rs](../../crates/fae-engine/src/engine_rt/skill_runtime.rs)、[mcp_runtime.rs](../../crates/fae-engine/src/engine_rt/mcp_runtime.rs)：需补充版本、能力声明、连接治理和策略边界 |
| 取消 | 已有上下文 abort 与调度检查 | [Context](../../crates/fae-agent/src/context.rs)、[plan_runtime.rs](../../crates/fae-engine/src/engine_rt/plan_runtime.rs)：需要覆盖执行中的 I/O、流、子任务和子进程 |
| 模型兼容 | 已支持 OpenAI 风格协议 | [model.rs](../../crates/fae-agent/src/model.rs#L3-L8)、[model_runtime.rs](../../crates/fae-engine/src/engine_rt/model_runtime.rs)：协议类型直接暴露 async-openai；不是独立的跨供应商语义模型 |
| 可观测性 | 已有事件、日志和 hook | [SessionEvent](../../crates/fae-agent/src/session/mod.rs#L160-L174)：还缺统一的运行关联、usage 汇总、轨迹存储和导出契约 |
| 检查点与审批恢复 | 审查范围内未发现完整协议 | [PlanNext](../../crates/fae-agent/src/plan/plan_define.rs#L5-L15) 只有 Tasks/End；任意 Plan 状态、等待中的任务与审批没有统一快照/恢复入口 |
| 结构化最终输出 | 工作流可返回 JSON，Agent 主要返回文本 | [响应处理](../../crates/fae-agent/src/plan/single_agent/execution/response.rs#L119-L128)、[WorkflowActionResponse](../../crates/fae-agent/src/workflow/definition.rs#L215-L219)：需增加显式输出模式与运行时校验 |

“未发现”仅指本次两个 crate 的代码范围。外层应用可能通过自定义 hook 实现部分功能，不能由此声称整个项目或所有使用者完全缺少该能力。循环与并行的组合扩展，应在统一节点状态、循环轮次和汇合规则后推进。

### 2.2 应保留的设计约束

- 工作流结构拓扑与执行状态分离；继续校验唯一起点/终点与可达性。
- Agent、Workflow、普通 Tool、MCP 保持明确路由类型，不用字符串别名掩盖协议错误。
- hook 按注册顺序组合，错误传播规则明确；核心状态机不能依赖提示词或可选 hook 才能正确运转。
- `user_id` 继续传播到会话、记忆、todo 和父子调用；新增 `run_id` 不能替代现有用户与会话维度。
- 默认工具迭代限制、`history_turns = 10`、图片 token 估算和语义重试保留兼容；预算是新增的全局控制。
- HTTP 重试与模型层重试只有一个明确所有者；当前默认路径存在叠加，需恢复内层重试显式禁用约束并持续验证。

## 3. 短板如何转化为建设任务

### 优先修复的五项具体缺陷

以下为经过调用链核对、按影响和证据选出的首批修复项，均为 **P1，置信度 10/10**；本次未确认 P0。P1 表示在明确条件下影响正确性、控制边界或资源使用，不表示无条件发生。完整触发条件、代码片段和建议见 [代码审查报告](review.md) 或 [HTML 报告](review.html)。

| 编号 | 问题与触发条件 | 代码位置 | 近期行动 |
| --- | --- | --- | --- |
| F1 | 依赖命令工具的目录限制时，shell 控制语句可绕过破坏性目标检查 | [command.rs:284–320](../../crates/fae-engine/src/tools/command.rs#L284-L320) | 明确可信/受限模式；短期拒绝无法解释的语法，长期以 OS 隔离执行边界 |
| F2 | 非默认用户的 Workflow 经 Tool 调用 Agent/Workflow，丢失身份并使用 `master` 分区 | [agent.rs:81–89](../../crates/fae-engine/src/tools/agent.rs#L81-L89)、[Workflow Tool 构造](../../crates/fae-agent/src/workflow/plan.rs#L551-L563) | 统一可信调用上下文，所有委派路径继承身份 |
| F3 | 默认模型 Client 的 HTTP 重试与 ModelRuntime 外层叠加，持续可重试故障下最多 16 次请求 | [model_runtime.rs:86–102](../../crates/fae-engine/src/engine_rt/model_runtime.rs#L86-L102)、[内层默认值](../../crates/async-openai/src/middleware/retry/openai.rs#L52-L55) | 显式禁用内层重试，统一分类、等待与取消预算 |
| F4 | Workflow 的 End/JoinEnd After hook 失败前，成功终态已发给消费者 | [workflow/plan.rs:431–439](../../crates/fae-agent/src/workflow/plan.rs#L431-L439) | 所有可失败完成步骤结束后，只提交一次终态 |
| F5 | 同 Agent/用户的多个 todo 执行，clear 与 ID 重用导致互相完成任务 | [single_agent_todo.rs:524–529](../../crates/fae-agent/src/plan/single_agent_todo.rs#L524-L529)、[todo 路径](../../crates/fae-engine/src/tools/todo.rs#L315-L323) | 引入 episode 身份或执行租约，隔离计划所有权 |

F3 的 16 是当前默认本地配置计算出的上界：外层 4 次尝试 × 内层每次最多 4 次发送，不是实测数据，也不包含后续语义重试；自定义 Client 策略及已建立流的消费错误不适用这个上界。F1 不等同于已证明的未认证远程执行；F2 的目录分区错误也不代表已经验证了外部多租户入口。F4 不意味着所有调用入口都会返回成功：WorkflowRuntime 仍能得到 Plan exec 的 hook 错误，但提前成功的 Session 事件和结果已经暴露。

### 3.1 执行状态与恢复

当前 `Plan` 接受和返回进程内任务对象，`AnyType` 是 `Box<dyn Any + Send>`，模型响应也可能包含不可序列化的流。会话 JSONL 保存对话内容，todo 保存任务列表；二者都无法单独重建任意计划的待执行节点、模型调用位置、未决工具、父子关系和资源预算。代码依据：[common.rs](../../crates/fae-agent/src/common.rs)、[任务定义](../../crates/fae-agent/src/task/task_define.rs)、[计划协议](../../crates/fae-agent/src/plan/plan_define.rs)。

建设方向是增加独立的执行记录协议，先支持内置 SingleAgent 和 Workflow，再提供可选的自定义 Plan 持久化扩展。任意 Rust 对象自动序列化不可作为目标。LangGraph 明确区分运行检查点与长期数据 store，也明确恢复涉及重放和幂等设计，而不是从同一行代码继续。[cite:1](#source-1)[cite:8](#source-8)

### 3.2 控制面与资源生命周期

局部迭代上限解决不了跨 Workflow、todo 子回合和多 Agent 委派累计消耗。上下文 abort 也不等价于已经停止模型流、HTTP 请求或操作系统进程。应建立从根 run 继承到子 run 的 deadline、调用次数、token 预算、委派深度和并发限制；取消必须能唤醒等待者并驱动资源清理。

事件链路还需分层背压。当前 [SessionOutputChannel](../../crates/fae-agent/src/session/mod.rs#L622-L652) 使用无界队列：消费者长时间不读取时，流式输出会持续积压。另一方面，[EngineRuntime 转发器](../../crates/fae-engine/src/engine_rt/engine_runtime.rs#L176-L222) 在同一循环处理内部回调和公共事件，公共队列满时等待发送会阻塞同源后续回调。治理方案应分离必需调度和可选观察，保证终态可靠交付，并允许合并文本增量或持久化后分页读取。

### 3.3 工具执行边界

工具接口当前是描述、请求和响应，执行身份与策略通过上下文和调用附件局部传播。文件、命令、Python 和 HTTP 工具提供本地自动化能力，不能将其“能够访问系统”本身视为安全缺陷。[命令工具](../../crates/fae-engine/src/tools/command.rs#L49-L78) 已有破坏性命令目录检查，但这种命令字符串解析不能作为完整 shell 隔离边界。真正的建设缺口是：框架没有统一声明并强制执行工具权限、审批、工作区边界和审计的协议。

面向本地可信开发可提供明确的宽权限配置；面向服务、多人或不可信输入时应要求受限配置。`user_id` 的文件分区是数据组织方式，不能代替身份认证。工具白名单、模型 guardrail 和提示词也不能替代执行器的访问控制。

### 3.4 可验证输出与质量闭环

`ToolResponse` 中结果和错误均可表现为字符串，[with_error](../../crates/fae-agent/src/tool.rs#L77-L89) 将错误编码为 JSON 文本；模型消费侧主要提取文本、工具调用与结束原因。缺少可供策略直接判断的统一错误种类、usage 与输出约束，容易把“模型结束”当作“业务完成”。

近期应引入标准结果信封和可选输出 schema；业务成功由显式验收条件判断。Pydantic AI 将输出类型、JSON Schema、运行时验证与有限纠错结合，这个方向适合 Rust 用 `serde` 类型和 schema/validator 接口实现。[cite:7](#source-7) 对工具失败允许在预算内纠错，但认证失败、权限拒绝、取消和不明确的副作用不能一律自动重试。

### 3.5 模型、上下文和记忆

模型协议与 async-openai 深度耦合，有利于快速兼容 OpenAI 风格服务，但后续接入不同工具调用、思考块、多模态和 usage 语义时会扩大适配成本。应先提取供应商无关的消息、模型事件和能力声明，再按实际场景增量实现适配器。

用户记忆已有分类、来源置信等级与更新时间，见 [memory.rs](../../crates/fae-agent/src/memory.rs#L5-L33)。缺少的是按任务检索、可撤销更新、来源追踪和上下文预算，而不是“增加记忆功能”。优先使用确定性的筛选、去重和全文检索，只有评测证明收益后再引入向量索引或图记忆。

## 4. 外部框架对照

### 4.1 可借鉴能力

| 框架 | 官方文档确认的能力 | FAE 的现有对应 | 建议借鉴与限制 |
| --- | --- | --- | --- |
| LangGraph | 检查点、持久执行、重放、暂停恢复；checkpointer 与长期 store 分离 [cite:1](#source-1)[cite:8](#source-8) | Plan/Workflow、会话与用户状态存储 | 借鉴快照、幂等任务和状态命名空间；不照搬 Python 图 API，不承诺外部副作用 exactly-once |
| OpenAI Agents SDK | Agent as tool、handoff、MCP、sessions、guardrails [cite:2](#source-2) | Agent/Workflow 工具、MCP、Session、hook | 先完善已存在的委派路径；控制权转移仅在业务需要时增加 |
| OpenAI Agents SDK | 审批中断与 RunState 序列化、父 run 接收嵌套审批；trace/span 与脱敏配置 [cite:5](#source-5)[cite:6](#source-6) | hook、父子事件、Ctx | 借鉴可恢复审批与链路关联；权限变化时重新验证授权，不默认上传提示词和工具正文 |
| CrewAI Flows | 事件驱动流程、结构化状态、条件控制；`@persist` 可保存状态，默认 SQLite 实现 [cite:3](#source-3) | WorkflowMetadata、分支/并行/循环、JSON 输出 | 借鉴显式业务状态与场景模板；FAE 已有图执行器，优先统一其语义 |
| Pydantic AI | 模型适配、类型安全、evals、OTel、审批与持久执行 [cite:4](#source-4) | 泛型 Runtime 包装、hook、模型运行时 | 借鉴能力声明、评测和可选适配层；不引入 Python 运行时作为 Rust 内核必需依赖 |
| Pydantic AI | 类型化结果、schema 校验、输出纠错与 usage limits [cite:7](#source-7) | Agent 文本响应、Workflow JSON | 增加严格结构化输出和统一预算；区分流式部分结果与最终有效结果 |

以上是官方文档能力核对，并未运行外部框架做同任务基准测试。每个框架的具体功能描述属于该官方资料的单一来源事实；“控制、恢复、验证优先”的方向由多个独立项目交叉支持。没有依据认定任何框架在性能、准确率或成本上领先 FAE。

### 4.2 采用与暂缓原则

优先采纳能够映射到当前痛点的机制：快照/重放、取消树、审批等待、trace/span、结构化结果、能力声明与评测。用 Rust 的 enum、trait、serde 和 Tokio 生命周期表达这些机制。

暂缓自治群聊、复杂角色市场、通用知识图谱、全量连接器和可视化编辑器。它们不是无价值，而是依赖稳定执行语义与明确需求。也暂不建设自有分布式持久调度平台：本地持久执行成熟后，可评估与既有工作流引擎集成。

## 5. 目标架构与模块职责

### 5.1 四层分工

```mermaid
flowchart TB
    A["应用层：CLI / 服务 / 场景验收与审批交互"]
    C["fae-agent：Plan、状态协议、策略与事件契约"]
    R["fae-engine：调度、取消、重试、审批、快照协调"]
    I["适配层：Model / Tools / MCP / Storage / Telemetry"]
    A --> C --> R --> I
    R --> DB["状态后端：先 SQLite；JSONL 保留导入导出"]
    R --> TR["本地轨迹与可选 OTel 导出"]
```

| 模块 | 建议职责 | 不应承担的职责 |
| --- | --- | --- |
| `fae-agent::execution`（拟新增） | run/task 标识、状态、预算、错误、暂停原因、快照协议 | 具体数据库与后台调度线程 |
| `fae-agent::tool` | 请求/结果信封、schema、能力与副作用声明 | Shell 隔离、网络连接和数据库事务 |
| `fae-agent::model` | 供应商无关消息、事件、usage、模型能力 | 供应商 HTTP 重试与认证细节 |
| `fae-engine` 调度模块 | 任务生命周期、资源树、背压、父子终态、策略执行 | UI 审批弹窗与业务成功规则 |
| `fae-engine` 状态模块 | 检查点、调用结果记录、事务与恢复加载 | 从聊天文本猜测程序计数器 |
| 模型/工具/MCP 适配器 | 执行能力、清理资源、转换错误、提供可验证结果 | 任意扩大继承权限 |
| 遥测与评测适配模块 | 脱敏轨迹、usage 汇总、回放、断言与指标 | 默认外发用户内容 |

新增模块名为建议，不是要求立即拆出多个 crate。先以可选模块和稳定 trait 建立边界，待依赖或发布周期确实不同再拆包。

### 5.2 执行状态与错误

拟议 run 状态为 `Created → Running → Waiting/Paused → Running → Succeeded/Failed/Cancelled`；取消过程可有 `Cancelling`。`Waiting` 要携带原因，如审批、外部结果、重试等待。终态一旦写入不能被迟到回调覆盖，父任务要明确子任务全部成功、部分成功或取消的规则。

至少区分以下错误：`InvalidRequest`、`UnavailableTool`、`PermissionDenied`、`ApprovalRejected`、`RateLimited`、`TransportFailure`、`ModelProtocolError`、`OutputValidationFailed`、`BudgetExceeded`、`Cancelled`、`StorageFailure`、`SideEffectUnknown`。错误带可重试性、阶段、调用标识和安全的模型反馈文本；底层错误链留给诊断接口。

保留 `AnyType` 用于进程内扩展；对持久化、远程调用和公共事件要求显式版本化 DTO。先添加可选能力接口，避免一次性修改全部 Runtime、Plan 和 hook。

### 5.3 检查点与副作用

检查点至少包含：版本、`run_id`、父 run、用户/Agent/会话身份、配置摘要、计划类型及状态、节点就绪/等待/完成集合、pending 调用、对话与压缩状态引用、预算使用、审批记录和最后已提交事件序号。

副作用调用采用“记录 intent → 执行 → 记录 outcome → 提交后续状态”。结果确认后恢复可以复用记录；如果外部系统已执行但本地结果未提交，状态应标记为不确定。支持幂等键的工具可安全查询或重试；不支持的操作须查询对账、补偿或交给用户决策。记录不能消除外部系统与本地事务之间的故障窗口。

内置计划实现快照恢复；自定义计划显式声明 `Ephemeral` 或 `Resumable`。恢复时核对配置/工具/模型版本和权限变化，迁移失败给出明确错误，不能静默沿用旧状态。

### 5.4 策略与审批

拟议工具能力声明包含：读写范围、网络访问、进程执行、敏感数据、外部副作用、幂等性和所需授权。策略返回 `Allow`、`Deny` 或 `RequireApproval`；普通 Tool、MCP、Agent 与 Workflow 的执行入口都必须经过同一控制面。

审批记录绑定具体用户、run、工具身份、参数摘要、资源范围与有效期。子 Agent 权限是父授权与自身配置的交集；审批不得自动给同名但不同执行器的工具授权。审批等待写入快照并释放执行槽；重启后仍可显示、拒绝和恢复。[cite:5](#source-5)

## 6. 分阶段路线与验收

### 6.1 阶段 A：正确性与离线基线

**建议窗口：第 0–2 个月。** 目标是现有 Agent 与 Workflow 在异常条件下能够得到确定结果。

工作内容：

- 将审查确认的缺陷拆成小修复，并为实际触发链路增加回归场景。
- 定义终态、批次回调与清理规则；取消能结束等待中的 run，而不是等待某个结果回调后才发现取消。
- 对高风险 read-modify-write 状态定义锁、事务、原子替换及跨实例行为。
- todo 编排增加执行 episode 身份、补充输入归属和成功判据；用户级 todo 集合与运行中的计划状态分开管理。
- 分离离线测试与真实模型集成测试；测试默认不依赖密钥和付费网络调用。
- 整理现有 Workflow 两条执行路径的语义矩阵，保护已经存在的并行、汇合和循环能力。
- 记录现有 hook 调用顺序、错误传播、请求变换后重新校验等契约。
- 将公共 mode 与核心执行阶段逐步改为类型化 enum，配置字符串在解析边界转换；保持旧配置兼容。

验收：

1. 离线库测试在无模型密钥环境下通过，真实模型测试显式启用。
2. 失败、取消、迟到/重复回调和消费者退出有确定终态，资源清理可断言。
3. 并发存储场景不会丢失已确认更新；损坏数据能报告并保留原始证据。
4. `cargo fmt`、`cargo check` 和相关回归检查进入 CI。

退出门槛：本次确认的高优先级缺陷有修复或有明确隔离措施；未通过时不推进复杂协作功能。

### 6.2 阶段 B：统一控制、预算与追踪

**建议窗口：第 2–4 个月，依赖阶段 A。**

工作内容：

- 增加 `run_id`、父子关系、调用标识、错误信封与统一 usage。
- 建立 deadline、模型请求数、工具次数、委派深度、token 与并发预算；父子共享总额度。
- 对模型流、HTTP、MCP 和子进程实现取消感知；进程清理覆盖后代进程及输出管道。
- 增加工具策略执行入口与 schema 校验；策略拒绝可转为安全的模型反馈。
- 记录 run/model/tool/node span、重试、取消、压缩和终态；默认本地存储，外部导出可选。
- 定义事件背压、文本合并、终态保留和消费者断开行为。

验收：

1. 无输出模型流、循环 Workflow 和递归委派均能由全局预算终止。
2. 子任务无法绕过父任务的额度、权限和取消。
3. 能从一个 `run_id` 找到完整调用树和错误原因；缺失 usage 标记为未知，不计为零。
4. 脱敏失败时禁止外发原始载荷；慢消费者不会造成无限内存积压。

### 6.3 阶段 C：本地持久执行与审批恢复

**建议窗口：第 4–7 个月，依赖阶段 A、B。**

工作内容：

- 抽象 `CheckpointStore`、调用结果记录与状态版本；先实现 SQLite 事务后端。
- 内置 SingleAgent、todo 编排和 Workflow 提供显式快照恢复。
- 为有副作用的工具引入 intent/outcome、幂等键与不确定状态。
- 实现审批中断、决策记录、拒绝反馈、恢复和授权再验证。
- 提供运行查询、取消、恢复和状态导出接口；CLI 是第一个消费端。
- 定义检查点保留、日志压缩、清理和格式迁移规则。

验收：

1. 在工具执行前、外部副作用后/本地提交前、结果提交后分别注入进程退出，恢复行为与契约一致。
2. 已确认调用复用记录；不确定副作用不会被静默重复执行。
3. 审批跨进程重启可恢复；拒绝、过期、权限变化和部分批准可解释。
4. 并行分支恢复不会丢失完成节点或重复汇合；循环恢复保留迭代与预算。
5. 无法恢复的自定义 Plan 明确标注，不影响既有临时计划运行。

### 6.4 阶段 D：模型、输出与上下文质量

**建议窗口：第 7–10 个月；部分工作可在 B 后提前进行。**

工作内容：

- 供应商无关模型消息/事件，保留 OpenAI 兼容适配；根据需求再选第二种原生协议验证边界。
- 能力声明覆盖 tool calling、并行调用、结构化输出、多模态、usage 与流式结束语义。
- 增加文本/JSON/schema 三类输出模式；验证失败在预算内纠错。
- 上下文按系统约束、用户记忆、历史、工具结果、任务产物分配预算。
- 原始工具产物独立存储，通过引用和摘要进入提示词，保留来源与可追溯性。
- 用户记忆增加撤销、来源和按任务检索；优先全文与结构化过滤。
- 建立固定任务集、离线模型轨迹和可选真实模型评测。

验收：

1. 两类模型协议跑同一契约测试，工具调用、终态与错误能统一表达。
2. 最终输出经 schema 校验才标为成功；流式部分结果不会触发业务提交。
3. 压缩不丢失未完成任务、关键约束、产物引用和待决审批。
4. 模型、提示词、压缩策略变更均有相同任务集下的质量/成本证据。

### 6.5 阶段 E：场景化协作与可嵌入交付

**建议窗口：第 10–18 个月，依赖 C、D 的验收结果。**

优先交付两个参考场景：

| 场景 | 用户价值 | 对核心能力的验收 |
| --- | --- | --- |
| 可恢复编码助手 | 长任务分步执行、修改可审查、失败可恢复、产物可追踪 | 工作区权限、命令取消、todo/Workflow 快照、测试结果验收、父子预算 |
| 可审批业务自动化 | 检索/整理/生成之后，由人确认外部写入 | 结构化输出、MCP 策略、幂等或对账、审批跨重启、审计与错误反馈 |

协作增强围绕任务完成：明确委派输入、输出 schema、产物引用、deadline、预算、错误和验收器。先完善 Agent as tool 的扇出/汇合与局部重试；handoff、动态选专家和共享记忆在场景要求下引入。对写共享工作区的 Agent 提供隔离目录或 worktree 与显式合并步骤。

交付形态以可嵌入 Rust 库、CLI 和最小服务适配为先。HTTP/SSE 服务需要身份认证、并发 run、恢复与事件游标；默认 `master` 用户只能用于本地兼容。分布式执行、A2A 和图编辑器作为条件性扩展，必须先有具体消费者与维护预算。

## 7. 第一轮实施清单与依赖

### 7.1 建议的首批工作包

| 顺序 | 工作包 | 主要落点 | 产出与依赖 |
| --- | --- | --- | --- |
| 1 | 审查缺陷修复 | 具体缺陷所在执行/运行时模块 | 小范围修复、触发链路与回归；先于新协议 |
| 2 | 离线测试基线 | `fae-engine` 模型测试与 CI | 默认无密钥运行；真实模型测试单独选择 |
| 3 | 生命周期契约 | `Ctx`、`PlanRuntime`、Runtime | 终态与取消清理规则；为快照和预算打基础 |
| 4 | 结果与错误信封 | `tool.rs`、`event.rs`、模型适配 | 可重试性与业务状态分离；兼容旧字符串接口 |
| 5 | 全局预算与追踪 | 调度、模型、父子委派、SessionEvent | 运行树、用量与背压；依赖统一标识 |
| 6 | 存储协议与 SQLite | Session/Memory/Todo 与执行状态模块 | 先解决一致性，再支持内置 Plan 快照 |
| 7 | 策略与审批 | 工具入口、MCP、Plan 暂停/恢复 | 即时 Allow/Deny 可先做，持久审批依赖快照 |
| 8 | 结构化输出与评测 | 模型协议、Agent 响应、评测适配 | 以固定任务集证明模型和策略改动收益 |

不要在一次变更中同时重构 Runtime、Plan、Session 和模型协议。每个工作包先写出契约、最小使用示例和验收场景，合入兼容层后再迁移调用方。

### 7.2 依赖图

```mermaid
flowchart LR
    A["缺陷修复与离线基线"] --> B["终态与取消"]
    B --> C["标识 / 错误 / 预算 / 追踪"]
    A --> D["存储一致性"]
    C --> E["内置 Plan 快照"]
    D --> E
    C --> P["即时权限策略"]
    P --> H["持久审批"]
    E --> H
    C --> V["结构化输出与评测"]
    V --> S["场景化协作"]
    H --> S
```

## 8. 评测、指标与质量门槛

以下是**拟议的采集口径和验收场景**，没有现成基线，不给出未经测量的改善百分比或延迟承诺。

| 维度 | 采集口径 | 验收方式 |
| --- | --- | --- |
| 正确性 | 有明确终态的 run；业务验收通过的 run；两者分别统计 | 固定任务集断言产物、schema、约束与工具结果 |
| 恢复 | 故障点、已提交结果复用、重复副作用、不确定调用处理 | 崩溃注入和重新启动；副作用账本对账 |
| 取消 | 取消请求到终态/资源释放的时长；残留任务/进程 | 分别覆盖模型流、工具流、子进程和委派 |
| 一致性 | 并发更新后的已确认条目、版本冲突、损坏恢复 | 多任务、多实例及将来多进程存储契约测试 |
| 成本 | 模型请求数、实际/估计 token、压缩次数、工具调用 | 同一任务集比较；缺失供应商用量标为未知 |
| 资源 | 并发槽、事件队列、存储大小、慢消费者积压 | 慢消费、长输出、循环与断开场景 |
| 安全边界 | 拒绝执行、授权变化、跨用户访问、审批绕过 | 工具/MCP/子 Agent 均经策略检查 |
| 可维护性 | 新适配器需要的协议转换、兼容与迁移路径 | 最小适配示例、契约测试、文档同步 |

确定性层使用 mock model/runtime、预录轨迹和故障注入；随机性层使用显式启用的真实模型评测。LLM judge 可作辅助，但产物正确性、schema、权限和副作用不能只由另一个模型判定。

阶段 A 首先建立可重复基线。之后再给出目标值、样本范围、模型版本、运行环境与测量方法；任何“提升成功率”或“降低成本”必须能追溯到这些条件。

## 9. 兼容、风险与取舍

### 9.1 兼容策略

保留既有 `Engine::launch`、Agent 配置、工具名、用户目录分区与 JSONL 可读性。新增 run 控制、输出模式、预算和持久能力优先可选启用；对无法提供恢复能力的扩展保持临时执行模式。

持久格式和公共事件增加版本字段。SQLite 上线先提供旧会话/记忆/todo 的导入、导出与回滚说明，不要求第一步迁移所有用户数据。恢复与配置热更新发生冲突时优先显式报错或受控迁移。

hook 仍用于扩展、变换与观测；预算、权限、终态和快照提交在引擎内部执行。请求被 hook 改写后仍须重新校验权限与 schema。

### 9.2 主要风险

| 风险 | 对策 |
| --- | --- |
| 把所有扩展对象持久化导致接口膨胀 | 内置计划先支持；自定义 Plan 显式声明可恢复能力 |
| 重放重复文件写入或外部调用 | intent/outcome、幂等键、结果查询和不确定状态；不做 exactly-once 泛化承诺 |
| 更严格权限破坏本地工作方式 | 明确信任配置与受限配置；保持本地兼容，服务部署要求真实身份 |
| 引入追踪泄漏提示词或工具数据 | 默认记录元数据；正文可选，本地优先，导出前统一脱敏 |
| 多模型适配拖慢核心治理 | 先抽象契约与第二协议验证，再按需求扩展 |
| 过早服务化扩大并发/隔离问题 | 先验收本地多 run 与恢复，再实现最小服务 |
| 长期规划变成能力清单 | 每项绑定用户场景、代码落点、依赖与退出门槛 |

### 9.3 规划维护

每个阶段结束更新本文件的能力判断与已验收证据；至少每季度复审优先级。新增方向需说明解决哪个实际失败、为什么现有 hook/tool/Workflow 不能满足、需要多少维护成本，以及用什么场景判断收益。

若持久执行和业务审批未出现真实需求，可以保持轻量执行内核，把阶段 C 压缩为可选存储接口；若编码助手成为主要场景，则优先工作区隔离、产物与取消质量。资源分配应跟随真实使用证据，而不是跟随框架流行功能。

## 10. 审查与验证方法

本次按三个功能组审查完整源码：Agent 计划/工作流/共享接口、Engine 调度与运行时、Engine 内置工具。审查维度覆盖逻辑、业务语义、安全边界、并发、健壮性、性能与质量；规划机会与具体缺陷分开处理。

验证结果：

| 检查 | 结果 | 解释 |
| --- | --- | --- |
| `cargo check -p fae-agent -p fae-engine --locked` | 通过 | 两个目标 crate 编译检查通过 |
| `cargo fmt --all -- --check` | 通过 | 工作区格式检查通过，未修改源码 |
| `cargo test -p fae-agent -p fae-engine --lib --locked -- --skip test_model_runtime_exec_chat_completion_bits_ut --skip test_model_runtime_exec_streaming_chat_completion_bits_ut` | 通过 | `fae-agent` 90 项、`fae-engine` 47 项，共 137 项通过；排除 2 项真实模型调用 |

两个被排除的测试位于 [model_runtime.rs](../../crates/fae-engine/src/engine_rt/model_runtime.rs#L206-L284)，依赖 `FAE_DEFAULT_MODEL` 和模型服务，没有 `#[ignore]`。该测试组织方式列为阶段 A 改进项。现有测试全部通过只能说明其覆盖场景通过，不能排除本次发现的未覆盖故障。

三个功能组完成后，另行核对共享接口、调用方保护与触发条件，修正了观察队列只阻塞同源回调、WorkflowRuntime 仍可返回 hook 错误、自定义模型 Client 不适用默认重试上界等影响边界。审查原始候选与生成过程保存在 `/tmp/free-agent-engine_faeplan_review/`；最终附件为 [review.md](review.md) 和 [review.html](review.html)。

静态审查无法证明线上不存在其他缺陷，也未验证不可信多租户部署、真实供应商中断或外部框架的运行表现。最终审查附件集中展示五项首批修复问题；其他生命周期、存储和流式控制风险体现在对应建设任务中。

## 11. 参考资料

外部资料均为官方文档，访问日期为 2026-10-30。文档可能持续更新；引用用于说明机制，不代表对应项目所有版本都支持相同 API。

<a id="source-1"></a>
- [cite:1] [LangGraph — Durable execution](https://docs.langchain.com/oss/python/langgraph/durable-execution)：恢复、确定性、任务结果复用与副作用幂等。

<a id="source-2"></a>
- [cite:2] [OpenAI Agents SDK — Overview](https://openai.github.io/openai-agents-python/)：基本原语、工具化 Agent、handoff、MCP、sessions 与 guardrails。

<a id="source-3"></a>
- [cite:3] [CrewAI — Flows](https://docs.crewai.com/en/concepts/flows)：事件驱动流程、结构化状态与持久化。

<a id="source-4"></a>
- [cite:4] [Pydantic AI — Overview](https://pydantic.dev/docs/ai/overview/)：模型适配、类型安全、评测、OTel、审批与持久执行。

<a id="source-5"></a>
- [cite:5] [OpenAI Agents SDK — Human-in-the-loop](https://openai.github.io/openai-agents-python/human_in_the_loop/)：审批中断、RunState、嵌套审批与授权范围。

<a id="source-6"></a>
- [cite:6] [OpenAI Agents SDK — Tracing](https://openai.github.io/openai-agents-python/tracing/)：trace/span、导出与敏感数据控制。

<a id="source-7"></a>
- [cite:7] [Pydantic AI — Output](https://pydantic.dev/docs/ai/core-concepts/output/)：结构化输出、验证、流式结果与 usage limits。

<a id="source-8"></a>
- [cite:8] [LangGraph — Persistence](https://docs.langchain.com/oss/python/langgraph/persistence)：检查点与长期 store 的职责差异。
