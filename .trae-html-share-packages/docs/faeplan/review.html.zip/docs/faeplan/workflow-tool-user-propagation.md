# Context 重构与 Workflow 工具委派身份传播方案

> 更新日期：2026-10-30  
> 对应问题：[审查第 2 项](review.md)、[长期规划 F2](long-term-roadmap.md)。  
> 源码基线：`3629748d91ed978723f001c35051f22886b42b42`。  
> 状态：Rust 重构与身份传播已实施；实现说明和验证结果见第 12 节。  
> 本版采用用户指定的 Context 方案，替换上一版 ToolCallContext 附件方案。

## 1. 本次设计决策

用户信息、session 及执行归属统一放入 `Context`。`TaskRequest` 已经携带 `ctx`，工具接口已经接收 `&Ctx`，因此工具从 `ctx` 获取身份、会话和归属；不在 `ToolRequest` 增加另一份用户上下文。

同时重构两个接口组：

1. 生命周期只保留 `state()` 和 `set_state(...)`。删除 Context 上的 `abort`、`is_aborted`、`over`、`error`、`is_completed`，并将现有 `wait` 的等待逻辑移至 `Ctx::result`，由状态订阅驱动。
2. 栈追加使用结构化 `ContextStack`，获取返回有序快照。记录至少包含完整 `TaskMeta`，并补充作用域、顺序、阶段、时间和父记录关系，替代按字符串 key 存放 Debug 文本。

关键配套决策是：**Context 的身份/会话作用域与执行状态分开建模；`clone()` 共享同一作用域，`fork()` 创建继承身份、独立状态的子作用域。** 用户可以沿整个调用树保持一致，但子 Agent 的 session 和子任务的终态不能覆盖父任务。

本次不是单独给 Context 加 `user_id` 字段。它涉及入口绑定、父子计划、运行时回调、结果消费、工具和 session 终态的统一迁移。

## 2. 实施前的问题与代码依据

本节描述上述源码基线的问题，行号也对应实施前版本。

### 2.1 用户在工具委派路径丢失

Workflow 的两条 Tool action 路径分别位于 [顺序执行器](../../crates/fae-agent/src/workflow/plan.rs#L551-L563) 和 [DAG 执行器](../../crates/fae-agent/src/workflow/plan.rs#L876-L888)。两者构造 `ToolRequest::new(...)`，没有传递用户。

[AgentTool](../../crates/fae-engine/src/tools/agent.rs#L81-L89) 缺少 Agent 专用 invocation 时使用默认用户构造；[WorkflowTool](../../crates/fae-engine/src/tools/workflow.rs#L69-L77) 缺少 Workflow invocation 时同样回落到默认用户。`alice` 的 Workflow 因而可能启动 `master` 的子执行。

直接 Workflow/SingleAgent action 能从 session 继承用户，但工具路径不能。这不是模型回答错误，而是执行环境交接错误。历史、记忆、todo 分区以及模型 `safety_identifier` 都可能受影响。

### 2.2 ctx 已传递，但没有作用域信息

[TaskRequest/TaskReq](../../crates/fae-agent/src/task/task_define.rs#L38-L109) 已携带 `Ctx` 与 `TaskMeta`；[Tools::exec](../../crates/fae-agent/src/tool.rs#L127-L132) 也已经接收 `&Ctx`。缺失的是 Context 中统一、可信的用户与 session 信息。

当前 [Context trait](../../crates/fae-agent/src/context.rs#L35-L54) 将完成/取消拆为多组方法。[EngineContext](../../crates/fae-engine/src/context.rs) 内部维护 `Pending/Ready/Aborted/Consumed`，成功或失败结果被读取后变成 `Consumed`，原始终态没有完整保留。

### 2.3 现有栈缺乏结构

当前 `append_stack(key, value)` 和 `stacks()` 使用 `HashMap<String, Vec<String>>`。[RuntimeSelectExecWrapped](../../crates/fae-agent/src/runtime/runtime.rs#L197-L208) 将 `TaskMeta` 格式化成 Debug 字符串再追加。

这有三个限制：任务元信息不便按字段查询、不同 runtime 间缺少统一顺序、派发记录不能表达完成/失败及耗时。已有 `ContextStack` 仅包含 `use_time_mill`，尚未成为实际记录类型。

### 2.4 不能复用一个可变根 Context 解决全部问题

当前 [AgentTool](../../crates/fae-engine/src/tools/agent.rs#L94-L108) 和 [WorkflowRuntime](../../crates/fae-engine/src/engine_rt/workflow_runtime.rs#L42-L63) 构建/执行子计划时复用 ctx。若在这个对象上修改用户、session 或写子执行成功，会影响父计划与并行兄弟。

因此应保留同一次执行的共享引用，但显式派生不同执行作用域。不能把“共享用户”解释成“共享所有可变状态”。

## 3. 目标结构与作用域

```mermaid
flowchart TD
    R["根 Context：alice / 根 session / 根状态"] --> P["Plan Context：继承 alice，独立状态"]
    P --> T["工具任务 Context：调用者 session / TaskMeta"]
    T --> A["子 Agent Context：alice / 子 session / 独立状态"]
    P --> W["子 Workflow Context：alice / 子 session / 独立状态"]
    R --> S["共享结构化 stack 存储"]
    P --> S
    T --> S
    A --> S
    W --> S
```

### 3.1 用户信息

拟议最小类型：

```rust
// 公共类型位于 fae-agent/src/context.rs。
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ContextUser {
    pub user_id: String,
    // 可选扩展：经宿主确认的用户属性。
}
```

用户信息来自顶层执行入口，进入运行态后不可改写。记忆内容和会话历史仍由各自 runtime 存储，不把全部历史、用户记忆复制进 Context。

`master` 只用于顶层本地默认初始化。工具拿到缺少已绑定用户的 Context 应报错，不能在工具内部再次选择 `master`。显式用户不得被工具 arguments、Workflow input、配置文件或 hook 返回值替换。

### 3.2 session 与执行归属

```rust
#[derive(Debug, Clone)]
pub struct ContextSession {
    pub session_id: String,
    pub session: CommonSession,
}

#[derive(Debug, Clone)]
pub struct ContextScope {
    pub scope_id: String,
    pub parent_scope_id: Option<String>,
    pub user: Arc<ContextUser>,
    pub session: Option<ContextSession>,
    pub agent_id: Option<String>,
    pub workflow_id: Option<String>,
    pub node_id: Option<String>,
    pub turn_id: Option<u64>,
}
```

`session_id` 表示当前作用域的会话归属。Agent 持久化会话通常有稳定 ID；没有持久会话的 Workflow 也应分配运行会话 ID，用于关联输出。两类 ID 的用途要在构造入口说明，不能把 Workflow ID 当作 Agent 持久化 session ID。

`CommonSession` 是会话句柄，供输入、输出和事件使用。它本身具有共享状态；父子 Context 不能随意复用同一句柄完成不同回合。子 Agent 创建适合现有事件转发关系的子 session，再绑定到子 Context；已有父会话转发机制应继续工作。

一般扩展任务允许 `session = None`、`agent_id = None`。需要会话或 Agent 归属的操作应返回明确的缺失错误，不推断一个虚假的会话或 Agent。

### 3.3 clone 与 fork

| 操作 | 用户与 session | 生命周期 | 栈 |
| --- | --- | --- | --- |
| `Ctx::clone()` | 同一作用域 | 共享同一状态 | 共享存储 |
| `ctx.fork(spec)` | 用户继承；会话/执行归属受控绑定 | 新建独立状态 | 共享存储，记录新的 scope_id |
| 新根 Context | 从入口建立 | 新生命周期 | 新的栈存储 |

`ContextChildSpec` 只允许提供子 session、目标 Agent/Workflow、节点、回合等归属，不允许提供另一个 `user_id`。会话用户必须与继承用户一致。

并行节点分别使用子 Context。子成功不完成父 Context；父取消向活动子树传播；子失败通过结果或事件交给父计划，由父计划决定是否失败、重试或继续。

## 4. Context 接口重新抽象

以下展示目标协议形状，具体字段封装可在实现时细化：

```rust
pub trait Context: Debug + Send + Sync + 'static {
    fn get_engine(&self) -> EngineRef;

    fn scope(&self) -> anyhow::Result<Arc<ContextScope>>;
    fn bind_scope(&self, scope: ContextScope) -> anyhow::Result<()>;
    fn fork(&self, spec: ContextChildSpec) -> anyhow::Result<Ctx>;

    // 生命周期仅有获取与修改两个入口。
    fn state(&self) -> ContextStateView;
    fn set_state(&self, state: ContextState)
        -> anyhow::Result<ContextStateUpdate>;

    fn append_stack(&self, entry: ContextStackDraft)
        -> anyhow::Result<StackEntryId>;
    fn stacks(&self, query: ContextStackQuery)
        -> anyhow::Result<Vec<ContextStack>>;
}
```

`scope()` 返回不可变快照。`bind_scope` 仅供根 Context 在 `Created` 阶段完成一次初始化；已绑定作用域再次绑定必须报错。`fork` 在创建时绑定完整子作用域，不开放执行中的用户/session setter。

`bind_scope` 是解决当前泛型 Engine 入口与 Agent 配置解析时序的初始化接口，不用于日常更新。未来可以把完整入口准备提前到 Context 构造时，再缩小这一接口的可见范围。

`ContextStateView` 是状态获取返回的句柄，提供 `current()` 快照和 `changed().await` 通知；Context trait 不再增加 `wait`、`is_completed` 等生命周期接口。`Ctx::result<T>()` 在便利层使用该句柄等待终态。

### 4.1 为什么状态获取返回可订阅视图

仅有同步状态快照时，结果等待只能轮询或依赖第三套通知接口。拟议 `ContextStateView` 可在内部封装 Tokio watch receiver，使一次状态获取同时支持读取和等待更新。

内部可采用 `watch::Receiver<Arc<ContextState>>`；对外封装可避免把 Tokio 细节暴露到每个调用方。新订阅者必须能立即读取当前终态，不能只监听未来事件。

### 4.2 ContextNull

`ContextNull` 不具有有效用户和 session，`scope()` 返回未绑定错误，不能返回默认 `master` 伪装成正常执行。允许继续用于不需要身份的工具描述查询或类型检查。

需要执行用户数据操作的 runtime 应拒绝空 Context。迁移测试中使用 `ContextNull` 的执行用例，必须明确哪些只验证协议，哪些需要换成有效测试 Context。

## 5. 状态模型与结果

### 5.1 类型定义

```rust
#[derive(Debug, Clone)]
pub enum ContextState {
    Created,
    Running,
    Succeeded { output: ContextOutput },
    Failed { error: Arc<ContextFailure> },
    Cancelled { reason: Arc<str> },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ContextStateUpdate {
    Applied,
    Unchanged,
}

// 概念结构：共享一个结果槽，支持 AnyType 单次消费。
#[derive(Clone)]
pub struct ContextOutput(Arc<Mutex<Option<AnyType>>>);
```

`ContextOutput` 实现安全的自定义 Debug；不要求 `AnyType` 可 Clone 或 Sync，结果槽由 Mutex 保护。错误和取消原因以可重复读取的共享数据保留。

成功状态与结果是否已消费分开：取出结果后仍为 `Succeeded`，不能改成丢失原始结论的 `Consumed`。结果保持现有单次消费契约；多个等待者可观察同一状态，但只有一个能取走成功输出。

### 5.2 状态转换约束

| 当前状态 | 允许的下一状态 |
| --- | --- |
| Created | Running / Failed / Cancelled |
| Running | Succeeded / Failed / Cancelled |
| Succeeded / Failed / Cancelled | 不允许写入其他状态 |

状态写入必须原子校验转换与发布通知，保证并发完成、失败和取消只有一个有效终态。相同非终态重复设置可返回 `Unchanged`；终态重复提交不以比较 `AnyType` 判断相等，应返回已终结错误并保留原结果。

`Succeeded` 必须携带结果，即使结果为 `()`；不能先标成功再晚些写入输出。错误在构建阶段发生时可从 Created 转 Failed。已取消后迟到成功或失败不得覆盖取消原因。

watch 只保证观察最新状态，不保证每个等待者看到所有中间转换；需要完整轨迹时写入结构化栈。实现应在状态锁内校验并提交完整值，随后通知订阅者，再记录诊断事件；诊断失败不能回滚已经对外可见的终态，也不能使状态提交持锁等待异步队列。若需要状态与轨迹事务化持久提交，再由后续存储协议统一处理。

### 5.3 原接口迁移

| 当前 Context 接口 | 新的表达 |
| --- | --- |
| `abort()` | `set_state(Cancelled { reason })` |
| `is_aborted()` | 从 `state().current()` 匹配 Cancelled |
| `over(value)` | `set_state(Succeeded { output: ContextOutput::new(value) })` |
| `error(message)` | `set_state(Failed { error })` |
| `is_completed()` | 从状态快照匹配任一终态 |
| `wait()` | 删除 trait 方法；`Ctx::result<T>()` 等待状态并读取结果 |

可以在状态值类型上提供 `is_terminal()` 等纯计算便利方法；Context trait 不保留六个旧生命周期方法。旧方法至多作为一次迁移期间的 deprecated 扩展适配，不形成长期双接口。

### 5.4 结果等待

`Ctx::result<T>()` 的拟议行为：

1. 获取状态视图并读取当前值。
2. Created/Running：等待视图变化，再重新检查。
3. Succeeded：从结果槽取一次值，进行 `downcast::<T>`。
4. Failed：返回保留的错误；Cancelled：返回取消错误与原因。
5. 结果已取走：返回单独的“结果已消费”错误，Context 仍保持成功状态。

错误类型转换不能先无条件取走结果再发现类型不符；优先检查 `AnyType::is::<T>()`，类型不匹配时保留原结果供正确消费者读取。

### 5.5 取消与清理

Cancelled 表示该作用域的逻辑终态，并通知等待者和取消感知执行器。它不证明 OS 子进程已经退出或外部副作用已经回滚；清理完成记录在栈里。

父取消对活动子 Context 传播同一原因。子任务成功不写父状态；父失败时停止剩余工作由调度器向活动子作用域提交 Cancelled。子取消不自动取消其他兄弟，是否终止父计划由其策略决定。

传播机制应由 Context 管理的子作用域注册及执行器的状态订阅实现，避免仅在下次回调检查取消。子引用注册使用弱引用或可清理注册，不产生父子强引用循环；不采用无限存活的后台观察任务。

`Plan::abort(code, error)` 是计划清理回调，不属于本次删除的 Context 方法。状态进入失败/取消后，PlanRuntime 仍须按既有契约调用它完成清理。

## 6. 栈追加与获取

### 6.1 栈记录结构

```rust
#[derive(Debug, Clone)]
pub struct ContextStack {
    pub entry_id: StackEntryId,
    pub parent_entry_id: Option<StackEntryId>,
    pub sequence: u64,
    pub scope_id: String,
    pub task_meta: TaskMeta,
    pub phase: ContextStackPhase,
    pub timestamp: String,
    pub elapsed_ms: Option<u64>,
    pub message: Option<String>,
}

#[derive(Debug, Clone)]
pub enum ContextStackPhase {
    Dispatched,
    Started,
    Succeeded,
    Failed,
    Cancelled,
    CleanupFinished,
}

// 调用方只提供记录内容；ID、sequence、scope 和时间由 Context 补齐。
#[derive(Debug, Clone)]
pub struct ContextStackDraft {
    pub task_meta: TaskMeta,
    pub phase: ContextStackPhase,
    pub parent_entry_id: Option<StackEntryId>,
    pub elapsed_ms: Option<u64>,
    pub message: Option<String>,
}
```

每条记录保存追加时的完整 `TaskMeta` 快照：`id`、`plan_id`、`ty`、`publisher`、`executor`。根 Context 生命周期记录也应建立明确的根 Plan 元信息，不能用任意空默认 Meta 替代。

Meta 的 `plan_id` 是调度回调关联，`scope_id` 是 Context 作用域，二者分开保留。结束记录关联开始记录 ID；同一任务在不同阶段可以有多条记录。

### 6.2 追加规则

- `append_stack(draft)` 在同一共享存储内原子分配 `entry_id` 和全局递增 sequence，形成完整 ContextStack；调用方不自行分配顺序。
- `scope_id` 由当前 Context 校验/补齐，不能伪造为兄弟作用域；记录的 TaskMeta 由已接受任务复制。
- 只接受任务的 runtime 写 Started；调用路由尝试失败不能写成已经执行成功。
- 开始耗时使用单调时钟；展示时间使用墙上时钟。不能将两种时钟混算。
- 异步 spawn 的返回只代表接收/派发，最终成功或失败由真实回调记录；流式任务的结束以流消费完成为准。
- 记录元信息与有限摘要，不默认保存完整请求、提示词、用户数据或结果正文。

当前 wrapper 的 `format!("{:?}", req.meta)` 应替换为复制 `req.meta` 的结构化记录。在消费 TaskRequest 之后，仍从 typed request 取得同一份 Meta；记录动作不得破坏原请求所有权。

### 6.3 获取规则

`stacks(query)` 返回记录快照，按 sequence 升序排列，至少支持：

- 查询当前 scope 或整棵执行树。
- 按 task_id、plan_id、runtime/executor 和 phase 筛选。
- `after_sequence` 游标与 limit，避免每次复制全部长任务日志。

append-only 存储用结束记录补充状态，不修改已返回的开始记录。若需要任务最终视图，读取侧按 TaskMeta 与父记录关系聚合。并行任务记录形成树状执行轨迹，不能当作只能 push/pop 的单线程栈。

默认追加有容量上限；溢出返回明确错误或转存后保留游标，并记录缺口。不得因为诊断容量满而使必需调度回调永久等待。重要终态记录可预留空间，完整持久轨迹后端在后续规划中实现。

## 7. 用户与 session 的入口绑定

### 7.1 根 Context 初始化

现有 Engine 泛型入口先创建 ctx，再把 Env 交给 builder；不能假定任意 Env 都有 user/session 字段。推荐保留这一流程，增加明确的一次绑定阶段：

1. 根 EngineContext 初始为 Created、scope 未绑定。
2. 内置 SingleAgent/Workflow builder 解析入口环境和必要配置，建立用户、session、执行归属并调用 `bind_scope`。
3. 默认本地用户只在这里解析；需要配置提供 Agent session_id 时也在这里完成。
4. 构建完成后 Engine 验证已绑定作用域，再转 Running 并开始执行。
5. 自定义 Plan builder 要显式绑定作用域，或宿主在调用前提供完整根 Context；通用旧 API 可有明确的顶层默认初始化适配。

根配置解析期间如果需要带用户的 runtime 操作，应先用已解析用户准备相应初始化作用域；不得在身份未绑定时读取用户历史/记忆。普通配置文件/Skill 描述加载不应以不完整身份偷偷触发用户数据操作。

用户和 session 一旦绑定，`scope()` 成为执行期间的唯一事实来源。现有 Env 的用户/session 字段在入口仍可作为初始化参数，但在运行时不作为第二套可变身份；builder 不再通过默认构造覆盖已有子 Context。

### 7.2 子作用域初始化

父作用域已绑定时，子委派按目标配置解析子 Agent/session，创建 child spec 并 `fork()`。子用户从父 Context 继承，Env 中历史字段如仍保留，只能校验一致或由 adapter 填充，不能覆盖继承身份。

`fork()` 必须原子检查父状态仍可接受子工作并注册子作用域；父已经终结时拒绝创建新的活动子任务。创建与父取消并发时，新子作用域必须进入被取消集合，不能出现取消传播漏掉刚创建子任务的窗口。

`session_id` override 只在创建子 Context 时应用，用户保持不变。父 session 保持稳定，父子事件通过已有子 session 转发机制关联。

同一可复用 CommonSession 的不同 turn 必须有不同执行 Context。新回合不能把上回合已终结 Context 重新置为 Running，确保历史终态与结果仍可读取。

## 8. 工具、Plan 与 Runtime 的改动

### 8.1 TaskRequest 与普通工具

继续使用 `TaskRequest { ctx, meta, req }` 和 `Tools::exec(&Ctx, ToolRequest)`。ToolRequest 保留业务名称与参数；不新增 ToolCallContext，不在模型 function schema 加 user_id。

PlanRuntime 给任务分配独立的任务 Context 后填入 TaskReq。工具从 `ctx.scope()?.user.user_id` 获取用户，需要当前会话时读取 scope.session。

任务 Context 的 session 是调用者当前会话。工具如果委派新 Agent/Workflow，再派生独立子执行 Context，不能把调用者会话和状态直接改成子执行的值。

### 8.2 AgentTool

- 从 ctx 读取有效用户和调用者 session；未绑定身份明确失败。
- 保留 Agent 专用 invocation 对目标 Agent、source 和祖先链的限制。
- 重构 AgentToolInvocation：保留专用能力信息，迁出其中作为身份传播来源的父 session；父会话由 ctx 提供。
- 解析目标 Agent/session，派生子 Context；Env 以子 Context 用户构造并进行一致性校验。
- 用子 Context 构建和执行子 Plan，取子作用域输出，再转换为工具响应。
- 不在无 invocation 分支调用默认用户构造函数；无专用 invocation 可按已授权工具能力加载目标 Agent，但身份仍来自 ctx。

没有 session 的非交互根调用可创建绑定正确用户的新子 session；不需要伪造父会话。祖先链和目标限制不会仅因用户搬入 Context 自动存在，需继续保留并验证。

### 8.3 WorkflowTool

从 ctx 读取用户，按该用户创建子 Workflow session 和子 Context，用其启动 Workflow。`ToolInvocation::Workflow { user_id }` 不再作为运行身份来源，完成迁移后删除该身份专用变体。

Workflow 的顺序和 DAG Tool action 都直接传当前任务 Context；不再在这两处拼接用户附件。直接 Workflow/SingleAgent action 也采用相同的子作用域规则。

### 8.4 Memory 与 Todo

MemoryTool 从 ctx 读取用户；TodoTool 从 ctx 读取用户与当前 `agent_id`。缺少 Agent 归属时返回明确错误，不能把 Workflow ID 当 Agent ID。

移除仅携带身份的 `UserMemory`、`Todo` invocation 依赖；若后续需要 episode 等专用能力，可单独保留与身份无关的附件。Workflow 自己没有 Agent 归属时，直接调用 Agent todo 工具仍须明确目标作用域，不能仅因 Context 有用户就自动可用。

底层 Session/Memory/Todo 请求若仍显式带分区字段，要在派发或消费边界与 ctx 核对用户与对应 Agent/session 归属，避免有了 Context 仍允许手写请求访问其他分区。

### 8.5 状态提交所有权

| 执行层 | 可以提交的状态 | 不得直接提交 |
| --- | --- | --- |
| 普通 runtime | 当前任务 Context 的终态 | 父 Plan 或根 Context 的成功 |
| 子 PlanRuntime | 子计划作用域状态 | 无条件写根 Context |
| 父 Plan | 根据任务结果决定自己的状态 | 更改已结束子任务结果 |
| 根 Engine 驱动器 | 根执行最终状态 | 覆盖已经提交的终态 |

每个作用域确定一个终态提交所有者。Engine、Workflow End、PlanRuntime 不能继续分别用同一个 ctx 重复写结果。

为保留当前自定义 Plan 已设置类型化结果的行为，Engine 只在根状态仍为 Running 且未由约定所有者提交结果时写 `()`；不能覆盖 Workflow JSON 或自定义 Plan 的输出。后续可统一 Plan 输出协议，本次必须明确兼容规则。

### 8.6 回调与终态事件

任务成功时回调携带的是已成功的任务 Context；这类回调仍需交给运行中的父 Plan。不能把“ctx 已终结”当作丢弃全部 TaskResult 的理由。

新任务派发检查其活动状态和父作用域状态；结果回调检查父 Plan 是否仍活动、任务 ID 是否匹配，以及取消/迟到规则。父 Context 被取消后，迟到结果只记录诊断，不再次推进计划。

成功事件在可失败的 End/After hook 完成后发布；状态先确定终态再发一致的 session 事件。session 的事件消费不成为第二个竞争终态来源。保留其结果便利 API 时应读取对应 turn 的 Context，逐步迁出重复 completion 逻辑。

## 9. 修改文件与实施步骤

| 步骤 | 主要落点 | 产出 |
| --- | --- | --- |
| A | `fae-agent/src/context.rs`、`fae-engine/src/context.rs` | 用户/session 作用域、fork、状态模型、状态订阅、结果槽、结构化栈 |
| B | Engine、PlanBuilder、SingleAgent/Workflow builder、会话模块 | 根一次绑定；每回合/子执行独立 Context；入口兼容 |
| C | `runtime/runtime.rs`、EngineRuntime、PlanRuntime | 状态调用迁移、任务子作用域、取消传播、Meta 栈记录、回调规则 |
| D | Agent/Workflow/Memory/Todo 工具及 single-agent 构造路径 | 从 ctx 读取身份；清理身份 invocation；保留专用能力 |
| E | Workflow 两条执行器、session 事件与 completion | 统一 Context 终态所有者，发布顺序及结果兼容 |
| F | `app/fae/src/tui.rs`、examples、现有测试与文档 | 删除旧接口调用，更新栈查询、取消、类型化结果示例 |

实施顺序必须让每个提交可编译：先增加新抽象和短期适配，再迁移调用方，最后移除旧接口。最终 Context trait 只有 state/set_state 两个生命周期接口，不长期保留新旧两套。

保留 Plan::abort 清理回调，更新 Context 的 abort 调用；不能通过全局字符串替换删除两种不同语义的方法。也要区分 UI/browser 的 `error()` 与 Context::error。

新增 Context 类型位于 `fae-agent`，具体锁、通知与存储在 `fae-engine`。`TaskMeta` 若需导出 JSON 栈可新增 serde derive；不能把 Context/session/AnyType 一起强行序列化。

## 10. 兼容与边界

- 内置 Agent/Workflow Env 用户与会话字段先保留作入口参数，再逐步减少重复运行态字段。
- ToolRequest 的业务 JSON 格式保持，工具调用通过已有 ctx 传输信息。
- 旧直接工具调用想使用 master，须在顶层构造有效默认 Context；ContextNull 不再承担默认用户执行。
- session 存储路径、用户记忆和 todo 文件格式保持；过去写错到 master 的数据不自动迁移。
- 跨进程传输必须由认证入口重建 ContextScope；进程内 ctx/session handle 不以工具 JSON 序列化。
- hook 可以变换业务内容，但运行身份由已绑定 Context 决定；任意可信 Rust 扩展仍是宿主信任边界。
- 这次 Context 重构增加状态/取消表达能力，具体进程组终止、外部副作用恢复仍须由执行器落实。

## 11. 拟议验收用例

以下保留设计验收矩阵；实际已运行的验证范围见第 12 节。

| 编号 | 用例 | 关键断言 |
| --- | --- | --- |
| C1 | 根 alice 用户与 session 绑定 | env 初始化后，运行身份唯一来自 ctx；二次绑定失败 |
| C2 | Created 阶段缺失/非法身份 | 用户数据操作拒绝，不能回落 master |
| C3 | Context clone/fork | clone 共享状态；fork 继承用户并独立状态 |
| C4 | 并发 alice/bob 与兄弟节点 | 用户、session 和终态不相互覆盖 |
| C5 | Workflow 顺序/DAG → Tool(agent/workflow) | 两条执行路径都继承 alice，包括 channel 前缀 |
| C6 | 多层 Workflow/Agent 委派 | 每层用户一致，子 session 与事件归属正确 |
| C7 | Agent 专用 invocation | source、Agent 限制和祖先链保持；session 从 ctx 获取 |
| C8 | session_id override 与下一回合 | 只改变子 session；新 turn 新 Context，上轮状态不重置 |
| C9 | Memory/Todo 与手写分区请求 | 读取 ctx 归属，拒绝不一致用户；缺 Agent 归属明确失败 |
| S1 | 合法/非法状态转换 | Created/Running/终态规则，结果与成功原子提交 |
| S2 | 成功、失败、取消并发竞争 | 只有一个终态；迟到事件不能覆盖 |
| S3 | result 单次消费与类型错误 | 消费后状态保留；类型不符不取走正确结果 |
| S4 | 先完成后订阅、多个等待者 | 当前终态立即可见，无通知丢失，只有一个取走成功值 |
| S5 | 父取消、子成功/失败 | 父取消传播；子终态不会无条件完成父 |
| S6 | 终态任务结果回调 | 成功任务回调仍能推进活动父计划 |
| S7 | End After hook 失败 | 不提前发成功；session/Context 最终结论一致 |
| K1 | 栈任务元信息 | 完整 TaskMeta，与 task/scope 对应，无 Debug 字符串解析 |
| K2 | 并行记录顺序与父记录 | sequence 唯一递增，关联正确，不假定单线程栈 |
| K3 | spawn 与流式任务 | 派发非成功；真实完成记录阶段与 elapsed |
| K4 | 栈分页、过滤、快照与容量 | 稳定顺序、读取不变、容量满不阻塞内部回调 |
| M1 | app/fae 与自定义 Plan 示例 | 状态 API、栈查询与类型化结果编译及行为兼容 |

使用 mock model/runtime 和临时 session 目录验证身份，不以模型输出文本判断当前用户。状态竞争与通知需要并发测试，结果输出不可被这些测试伪造为“可重复 Clone 的 AnyType”。

实施检查：

```bash
cargo fmt --all -- --check
cargo check --workspace --locked
cargo test -p fae-agent -p fae-engine --lib --locked -- \
  --skip test_model_runtime_exec_chat_completion_bits_ut \
  --skip test_model_runtime_exec_streaming_chat_completion_bits_ut
```

工作区检查用于覆盖 app/fae 和 examples 的 Context 接口迁移；真实模型测试另行显式启用。

## 12. 实现与验证记录（2026-10-30）

已按 Context 作用域方案完成 Rust 迁移：

- `fae-agent::Context` 仅以 `state` / `set_state` 管理生命周期；`Ctx::terminal` / `result` 使用订阅等待。成功输出单次消费，类型不匹配保留结果，消费后保留终态。JSON/String 输出额外保存只读 session 快照，因此 `CommonSession::result` 不会因 Engine 已取走类型化输出而失效。
- `EngineContext` 实现一次根绑定、不可变用户/归属、任务与子执行 fork、父取消/失败向活动子树传播，以及有容量上限的结构化栈。任务 fork 继承执行归属；`ContextChildSpec.execution = true` 为新执行重新绑定 session、Agent/Workflow 和回合归属。
- Engine 和内置 builder 在运行前绑定作用域；子计划通过 `Engine::fork_call` 准备。普通 runtime 操作与父计划状态分离；Workflow 的顺序与 DAG 工具任务绑定对应 node。每个新 SingleAgent 回合创建新的根 Context，替换活动会话时主动取消旧回合。
- Agent/Workflow/Memory/Todo 从 Context 获取身份；删除仅携带身份的 invocation 变体。Agent 专用 invocation 继续保留目标、source 与祖先链，父 session 改从 Context 取得。Session/Memory 的执行请求校验分区字段与 Context 一致。
- PlanRuntime 根据活动父计划和 task ID 接收回调，允许成功子任务推进父计划；保留自定义类型化输出，取消与完成竞争时发送已提交终态对应的结果。挂起的 `init` / `next` 能被取消打断，清理后追加 `CleanupFinished`。Workflow End 的 After hook 在成功状态与事件之前执行。
- 模型及工具输出由消费过程提交完成状态。模型流在 EOF、错误或提前丢弃时结束；工具响应的最后一个消费句柄提前丢弃时取消任务。异步模型/工具执行也监听 Context 取消；逻辑取消不代表外部副作用已回滚。

新增回归位于 [EngineContext 测试](../../crates/fae-engine/src/context.rs)、[身份与流式集成测试](../../crates/fae-engine/src/context_integration.rs) 和 [PlanRuntime 测试](../../crates/fae-engine/src/engine_rt/plan_runtime.rs)，覆盖：

- 状态转换、并发终态唯一胜出、早/晚订阅与单次消费、类型错误保留输出。
- clone/fork 独立性、父取消与 fork 并发、失败取消孙作用域、session 用户不一致。
- 并发栈记录顺序、完整 Meta、父记录/耗时、子树过滤、分页、快照与容量溢出后的终态发布。
- 顺序/DAG → 带 `default__` 前缀的 Agent/Workflow 工具，多层委派及并发 alice/bob。断言直接检查 Context、模型 `safety_identifier` 与临时目录中的 session 分区，不依赖模型回答文本。
- 专用子 Agent 调用、session override、父事件转发、下一回合新 Context、空 Context 与分区不一致拒绝。
- End After hook 失败无成功事件、挂起计划取消与清理、自定义类型化输出，以及流式部分输出/EOF/丢弃/取消。

验证结果：`cargo fmt --all -- --check` 与 `cargo check --workspace --all-targets --locked` 均通过；fae-agent 90 项、fae-engine 61 项测试通过，共 151 项，0 失败。工作区检查覆盖 app/fae、examples 与测试目标；async-openai 测试目标存在原有 Assistants API 弃用警告。

真实模型联网用例按第 11 节命令显式跳过两项；进程组终止和外部副作用恢复仍属于执行器的后续工作。本次不迁移历史上误写到 master 分区的数据。
