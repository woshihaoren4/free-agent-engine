# 代码评审报告

- 仓库：free-agent-engine
- 检测模式：完整源码通用检测
- 检测范围：crates/fae-agent 与 crates/fae-engine 当前完整源码；基线 3629748
- 生成时间：2026-10-30 14:29
- 检查文件：68
- 审查源码行数：19744

本报告为当前完整源码审查，非提交 diff。首批召回 5 项 P1，未确认 P0；范围为两个 crate 的 68 个 Rust 文件、19,744 行源码，并核对包依赖和一层调用契约。缺陷按影响、置信度与根因去重选取，不代表全部潜在问题。静态触发链已核对；未实际执行破坏性命令、故障注入或真实模型故障。cargo check 与 cargo fmt 检查通过；137 项离线库测试通过，2 项真实模型测试排除。

[长期规划](long-term-roadmap.md)

## 缺陷统计

- P0：0
- P1：5
- P2：0
- 合计：5

## 缺陷详情

### 1. [P1][安全漏洞] Shell 控制语句可绕过声明的破坏性命令目录限制

- 位置：`crates/fae-engine/src/tools/command.rs:284-320`
- 置信度：10/10

**问题描述**

命令工具声明破坏性命令仅可作用于 FAE_HOST、进程工作目录或临时目录，并在执行前调用 validate_command_safety。但解析器按分号拆片，仅识别每片段的首个命令。非 Windows 的 sh -c 执行路径中，`if true; then rm -f /outside/victim; fi` 被识别为 if、then、fi，未命中 rm 检查，会允许删除安全根外且 OS 用户有权限删除的文件。触发条件是授予 execute_command 并依赖其目录限制；这不是已证明的未认证远程执行，也不将开放 shell 能力本身认定为漏洞。

**问题代码（306–320 行）**

```rust
        }
    }

    if name == "xargs" && mentions_destructive_command(segment) {
        return Err(
            "xargs cannot invoke destructive commands because its targets are dynamic".to_string(),
        );
    }

    if name == "find" {
        return validate_find(&words[command_index + 1..], cwd, safe_roots);
    }

    if !is_destructive_name(name) {
        return Ok(());
```

[源码位置](../../crates/fae-engine/src/tools/command.rs#L284-L320)

**修复建议**

短期拒绝无法完整解释的 shell 控制语句和改变执行目录的 wrapper，并明确此检查的能力边界。长期区分可信本地与受限执行模式，以 OS 文件系统隔离和统一能力策略执行边界；不能用分词黑名单承诺完整 shell 安全。

---

### 2. [P1][逻辑错误] Workflow 经工具委派时丢失当前用户并回落到 master

- 位置：`crates/fae-engine/src/tools/agent.rs:81-89`
- 置信度：10/10

**问题描述**

WorkflowAction::Tool 在 workflow/plan.rs:551–563 和 876–888 构造不带 invocation 的 ToolRequest。user_id=alice 的 workflow 调用 agent 工具时进入缺省分支 SingleAgentEnv::from_agent_id，用户变为 master，子 Agent 的历史、记忆和 todo 使用错误分区。workflow 工具的缺省分支也存在同类回落；直接 WorkflowAction::Workflow/SingleAgent 路径则正确继承用户，因此相同委派能力的身份语义不一致。非默认用户使用这条路径才出现分区错误，没有证据证明外部远程越权入口。

**问题代码（81–89 行）**

```rust
        let (mut env, session) = match req.take_invocation() {
            Some(ToolInvocation::Agent(invocation)) => {
                invocation.into_env(&args.agent_id, args.input)?
            }
            Some(ToolInvocation::Workflow { .. })
            | Some(ToolInvocation::UserMemory { .. })
            | Some(ToolInvocation::Todo { .. })
            | None => SingleAgentEnv::from_agent_id(args.agent_id, args.input),
        };
```

[源码位置](../../crates/fae-engine/src/tools/agent.rs#L81-L89)

**修复建议**

统一可信调用上下文，让 Workflow 的 Tool 分支传播 user_id、父 run/session 和祖先关系。嵌套委派缺少身份时明确拒绝，不静默改成 master；显式的本地顶层调用仍可保留默认用户兼容。

---

### 3. [P1][健壮性问题] 模型重试与默认 HTTP 重试叠加，持续故障下最多发送 16 次请求

- 位置：`crates/fae-engine/src/engine_rt/model_runtime.rs:86-102`
- 置信度：10/10

**问题描述**

ModelRuntime 外层为 3 次重试加最终请求，共 4 次 request_once。默认 Client 使用本仓库 async-openai 的 ReqwestExecutor；executor.rs:144–149 安装 OpenAIRetryLayer::default，middleware/retry/openai.rs:52–55 默认允许 3 次额外重试，即每次外层尝试最多 4 次 HTTP 请求。持续 5xx、可重试 429 或连接故障时，两层合计最多 4×4=16 次请求，等待也叠加。该数字为静态配置上界，不是实测流量；外层还不分类错误，会再次发送内层已判为不可重试的错误请求。当前默认构造路径没有显式关闭内层重试。

**问题代码（88–102 行）**

```rust
                Ok(response) => return Ok(response),
                Err(error) => {
                    wd_log::log_warn_ln!(
                        "model request failed, retry {}/{} in {}s: {:?}",
                        retry_index + 1,
                        RETRY_DELAYS.len(),
                        delay.as_secs(),
                        error
                    );
                    tokio::time::sleep(*delay).await;
                }
            }
        }

        Self::request_once(client, req).await
```

[源码位置](../../crates/fae-engine/src/engine_rt/model_runtime.rs#L86-L102)

**修复建议**

恢复单一重试所有者：默认模型 Client 显式禁用内层 HTTP 重试，由外层保留错误分类并只重试瞬时错误。将总请求数、等待时间和取消纳入统一预算；自定义 Client 明确声明其重试策略。

---

### 4. [P1][业务语义问题] Workflow 在 End 的 After hook 成功前发布终态成功

- 位置：`crates/fae-agent/src/workflow/plan.rs:431-439`
- 置信度：10/10

**问题描述**

顺序执行器先 emit_node_completed(..., true)，再等待 End 节点的 After hook；DAG 执行器在 1135–1143 也采用这个顺序。若 After hook 返回 Err，CommonSession 已记录成功终态，事件消费者可能已经结束读取；随后 PlanRuntime 才中止计划并发布失败。会话 result 仍保留之前成功，造成同一运行同时表现为成功与失败。触发条件是合法注册的 End/JoinEnd After hook 失败，不是对未来功能的要求。WorkflowRuntime 先等待 Plan exec 成功才取会话结果，因此该入口仍返回 hook 错误；缺陷集中于提前成功的事件与 Session 结果，并非所有入口都返回成功。

**问题代码（431–439 行）**

```rust
                    self.emit_node_completed(self.current.clone(), output.clone(), true)?;
                    self.invoke_hook(
                        &node_id,
                        &hook_node,
                        WorkflowHookPhase::After {
                            output: Some(&output),
                        },
                    )
                    .await?;
```

[源码位置](../../crates/fae-agent/src/workflow/plan.rs#L431-L439)

**修复建议**

先完成所有可能失败的 End/JoinEnd After hook，再发布成功、完成上下文并提交终态。终态一旦提交只能有一个结果，迟到失败不得制造相互矛盾的完成事件。

---

### 5. [P1][并发问题] 同 Agent/用户的并发 todo 执行会清空并完成彼此的任务

- 位置：`crates/fae-agent/src/plan/single_agent_todo.rs:524-529`
- 置信度：10/10

**问题描述**

不同 SingleAgentEnv 会话允许并发运行，但 todo 调用身份仅含 agent_id/user_id，并共同使用 session/<agent>/<user>/todo.json。每次 todo init 都 clear，工具 clear 又重置 next_id=1。A 创建任务 1 并执行期间，B 清空并创建另一个任务 1；A 随后 update(id=1, completed=true)，会把 B 的任务标为完成。单实例 CRUD mutex 只串行单次操作，不能隔离整段 planning/execution episode，因此即使没有文件写入数据竞争也会发生语义覆盖。

**问题代码（524–529 行）**

```rust
        Ok(PlanNext::Tasks(vec![
            self.todo_task(serde_json::json!({
                "operation": "clear",
                "user_input": self.todo.requirement
            }))
            .await?,
```

[源码位置](../../crates/fae-agent/src/plan/single_agent_todo.rs#L524-L529)

**修复建议**

给每段 todo 执行分配不可变 episode/plan ID，并加入调用身份、存储与更新条件；或短期采用 agent/user 级执行租约禁止重叠 todo 回合。保留用户级 todo 查询体验，但不能用 clear 和可复用数字 ID 表示执行所有权。

---
