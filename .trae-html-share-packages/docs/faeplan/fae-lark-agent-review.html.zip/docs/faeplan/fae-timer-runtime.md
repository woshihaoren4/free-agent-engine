# FAE 定时器 Runtime、Tool 与新会话执行方案

状态：已实施；验收记录见下文。  
日期：2026-11-05。  
范围：`crates/fae-agent`、`crates/fae-engine`、`app/fae`。  
依据：当前仓库源码及已实施的 [服务常驻与 TUI 分离方案](./fae-daemon-service.md)。

## 实施记录（2026-11-05）

已完成 `fae-agent` 公共定时契约、`fae-engine` 分区存储/时间计算/共享 Runtime/管理代理/
默认 `timer` 工具，以及 `app/fae` 服务级 Dispatcher、内部 Actor、新 session 显式身份启动
和终态回执。`fae init` 通过默认工具列表启用 timer，旧配置需自行增加工具名。

可信绑定采用 `ContextScope.timer_execution` 与 `ContextChildSpec.timer_source/timer_workspace`：
宿主设置来源和工作区，任务子 Context 继承绑定，单 Agent 构建器在 child spec 中绑定子
Agent 的真实来源。`ScopedTimerBindingResolver` 校验 scope 归属；可由嵌入式宿主提供其他
resolver。从顶层 workflow 进入 Agent 时，构建器提供可信 workspace，用户仍继承父 Context。
无需保存旧 Ctx 或维护额外的全局执行绑定表，绑定随 Context 生命周期释放。

落地参数：全 home pending 上限 256，定时并发上限 2，继续共享服务 8 回合/32 会话额度；
每 Agent/User 100 个未删除定义，全 home 1000 个；每分区终态触发记录最多 1000 条或
30 天，定义水位、tombstone、幂等键和非终态记录保留。调度每秒对照墙上时钟，CRUD 与
回执可唤醒，按 owner 轮转并按归属内部的到期时间排序投递。所有分区提交串行化，磁盘
操作进入阻塞线程；调用方取消不取消已开始的管理事务。

普通 chat 在当前 Single Agent API 中以 `mode = None` 表示；内部启动沿用此表达，
不传会被拒绝的显式 `"chat"` 字符串。查询使用 `cursor`，暂停/恢复使用 `enabled`，
delete 的 `expected_revision` 可选。未改变 WebSocket v1 envelope。

已通过可控时间的 cron/时区/DST、计数、重叠合并、时钟回拨、CRUD 幂等/版本/隔离、
pending 重投、running 恢复为 interrupted、单消费者、代理退出、存储错误和背压测试；
真实服务进程 + 本地 SSE 假模型验证了无客户端执行、clean 保留定时、配置用户/session
变更不覆盖归属，以及 repeat 跨服务重启生成独立 session 和落盘 history。

本次验证在 macOS 上执行；真实模型、真实 TUI、Linux/Windows 运行行为尚未验收。
原子替换采用 tempfile 的跨平台 persist，不能把本地验证视为所有平台验证。

验证命令：`cargo check --workspace --all-targets`、`cargo test -p fae-agent -p fae-engine -p fae`
已通过（248 项测试，其中 13 项定时契约测试、2 项服务定时端到端测试及 Actor 退出竞争测试）。
Actor 独立发送 cleanup 完成信号，服务关闭时等待该信号，覆盖定时 Actor 已离开命令接收
循环的场景；完成回合时按 registry lease 原子决定释放或继续保留，避免丢失排队中的客户端附着。
本次修改文件通过
rustfmt 检查与 `git diff --check`。`cargo fmt --all -- --check` 仍因仓库已有的未格式化文件失败，
包括 app/paths、server/replay、TUI 和 memory_runtime 等未修改模块。

下文保留原始方案作为设计依据；其中“建议”“尚未实施”描述的是方案编写时的状态。

## 1. 目标与设计结论

新增 `TimerRuntime`，使用 cron 表达式计算触发时间，支持一次定时、有限次数定时和无限循环定时。新增统一的 `timer` 工具，Agent 可以调用它创建、查询、修改和删除当前用户、当前 Agent 的定时任务。

时间到达后，Runtime 返回项目现有的 `Event`。后台服务消费事件，默认在任务归属的用户、Agent 和工作区下创建全新的 session，把保存的任务内容作为第一条输入执行。每次触发拥有独立 session；创建定时任务的对话退出、结束或取消，不影响已保存的定时任务。

核心选择：

- 每个 FAE home 的后台服务只运行一个调度器，由服务持有其生命周期。
- 每个 session 的 Engine 只安装定时管理代理，不重复启动调度器，不消费共享的到期事件队列。
- `TimerTool` 通过 `ctx` 中的 Runtime 调用定时管理接口，工具参数不能指定或覆盖 user、agent、session、工作区与配置来源。
- 复用 `EventType::Any` 承载类型明确的 `TimerFired`，暂不新增公共 `EventType` 变体。
- 默认到期后执行新会话；首版不提供复用原会话和直接执行 workflow 的动作。
- 定时定义和触发记录持久化；重启恢复采用有界补发，已进入执行交接的记录不自动重跑。

服务必须处于运行状态才能准时触发。用户关闭 TUI 后服务继续运行；停止服务、机器睡眠或关机期间无法执行，到下次恢复时按漏触发策略处理。本方案不新增操作系统级唤醒或开机自启动功能。

## 2. 当前项目接入依据

| 当前事实 | 源码依据 | 对方案的影响 |
| --- | --- | --- |
| `Runtime` 已提供 `watch`、`exec`、`exit`；默认可以不支持 `watch` | [runtime/runtime.rs](../../crates/fae-agent/src/runtime/runtime.rs) | 调度器可作为事件源，管理代理可以明确不提供事件源 |
| `TaskType` 已提供 `Any(String)` | [task/task_define.rs](../../crates/fae-agent/src/task/task_define.rs) | 管理请求使用 `TaskType::Any("timer")`，无需增加任务枚举变体 |
| `Event` 包含来源 Runtime ID，`EventType::Any` 可以携带 `AnyType` | [event.rs](../../crates/fae-agent/src/event.rs) | 到期事件使用现有扩展点，内部只在边界做一次类型转换 |
| `EngineRuntime::build` 会监听已注册 Runtime 的事件，随后转发到 Engine 队列 | [engine_runtime.rs](../../crates/fae-engine/src/engine_rt/engine_runtime.rs) | 不应把同一个调度器事件源注册到多个会话 Engine |
| `Actor::start` 按会话懒构建 Engine；清理和释放会话会调用 `engine.exit()` | [server/session.rs](../../app/fae/src/server/session.rs) | 定时器不能由某个 Actor 的 Engine 独占 |
| `Registry::open` 依赖 `Outbound`；Agent 用户默认来自加载配置 | [server/registry.rs](../../app/fae/src/server/registry.rs) | 需要内部无客户端入口，显式使用保存的任务归属 |
| `ContextScope` 包含 user、agent、session，但没有工作区或 Agent 配置来源 | [context.rs](../../crates/fae-agent/src/context.rs) | 工作区与来源需要由可信的服务执行绑定补充，不能从模型参数推断 |
| 单 Agent 构建器可以冻结来源；已绑定 Context 会校验用户、Agent、session 一致性 | [single_agent/builder.rs](../../crates/fae-agent/src/plan/single_agent/builder.rs) | 新会话可显式绑定身份，再走现有 Plan 构建校验 |
| `ToolsRuntime` 按 channel 注册，默认工具由一个 `DefaultTools` 聚合 | [tools_runtime.rs](../../crates/fae-engine/src/engine_rt/tools_runtime.rs)、[tools/mod.rs](../../crates/fae-engine/src/tools/mod.rs) | `timer` 应加入聚合工具，避免注册第二个 default channel 覆盖其他工具 |
| `fae-engine` 已依赖 `cron = "0.16.0"`、`chrono = "0.4.45"`；当前源码没有调度实现 | [Cargo.toml](../../crates/fae-engine/Cargo.toml) | 复用现有解析依赖，另补调度、持久化和服务事件消费 |
| 服务按 home 获取 `server.lock`；目前限制 8 个并发回合、32 个保留会话 | [server/mod.rs](../../app/fae/src/server/mod.rs)、[server/registry.rs](../../app/fae/src/server/registry.rs) | 同 home 单服务负责写入；定时会话必须共用资源限制 |

这些是当前实现事实。后续章节中的接口、字段、默认限额和处理策略均是本方案提出的设计，不代表已经存在。

## 3. 模块与生命周期

```mermaid
flowchart TD
    A[Agent 调用 timer] --> B[DefaultTools / TimerTool]
    B --> C[ctx Runtime: timer 管理代理]
    C --> D[服务共享 TimerRuntime]
    D <--> E[按 Agent / User 保存定时与触发记录]
    D -->|watch 返回 Event| F[服务 TimerDispatcher]
    F --> G[Registry 内部新会话入口]
    G --> H[独立 Actor / Engine / Context]
    H --> I[原用户、原 Agent、新 session 执行]
    I -->|启动确认与终态| D
```

### 3.1 建议模块

| 层级 | 新增或修改模块 | 职责 |
| --- | --- | --- |
| `fae-agent` | `timer.rs` 并在 `lib.rs` 导出 | 类型化管理请求/响应、定时策略、归属、执行绑定和到期事件契约 |
| `fae-engine` | `engine_rt/timer_runtime.rs` | 定时管理接口、共享句柄、管理代理 Runtime |
| `fae-engine` | `timer/scheduler.rs` | 下次触发计算、等待、唤醒、补发与背压 |
| `fae-engine` | `timer/store.rs` | 分区存储、事务式更新、版本校验与恢复 |
| `fae-engine` | `tools/timer.rs` | JSON 参数解析、schema、Context 归属校验、Runtime 转发 |
| `app/fae` | `server/timer.rs` | 服务级初始化、唯一事件消费者、执行绑定解析、内部会话分发 |
| `app/fae` | 现有 `server/registry.rs`、`session.rs`、`engine.rs` | 无客户端会话、共享定时句柄、显式身份启动、终态回执 |

将持久化逻辑、时间计算和执行状态分开。定时定义描述“何时、执行什么”，触发记录描述“某次触发执行到了哪里”，不以持有旧 `Ctx` 的方式保存任务。

### 3.2 服务级所有权

新增 `ServerServices`，保存共享 `TimerHandle`、可信执行绑定注册表和 Dispatcher。`Registry` 持有共享服务句柄，`build_engine` 接收该句柄，为每个 Engine 安装 `TimerClientRuntime`。

`TimerRuntime` 提供唯一的到期事件流；`TimerClientRuntime` 只转发管理请求，其 `watch()` 返回 `RuntimeNoSupport`，`exit()` 只释放代理资源。会话释放不能停止调度器。服务关闭时才调用真正的 `TimerRuntime::exit()`。

启动顺序：

1. 取得已有 `server.lock`，初始化存储并校验 schema。
2. 初始化 TimerRuntime，注册唯一 `watch()` 消费者和 Dispatcher。
3. 恢复 pending 记录并启动调度循环。
4. 在服务监听准备完成后发布 discovery 信息并报告 ready。

关闭顺序：停止接收新的定时变更和到期分发，完成当前存储提交；随后执行 Registry 的取消与关闭流程，接收终态回执，最后停止调度器并释放服务锁。已落盘但尚未交接的 pending 记录留给下次启动处理。沿用当前服务关闭超时；不能把停止 Engine 误当成删除定时定义。

`watch()` 是单消费者队列契约，重复注册必须报错；不能假定克隆 `Receiver` 会给每个接收方广播完整事件。嵌入式使用时，由宿主自行持有 TimerRuntime、消费 Event 并选择执行行为；没有宿主执行适配器时，工具返回 `timer_unavailable`。

## 4. 时间与次数语义

### 4.1 三类定时

使用带 tag 的 `TimerSchedule`：

| `kind` | 字段 | 含义 |
| --- | --- | --- |
| `once` | `cron`、`timezone` | 取启用后第一个符合 cron 的时刻，接受一次触发后结束 |
| `repeat` | `cron`、`timezone`、`max_fires` | 接受最多 N 次触发，N 为正整数 |
| `loop` | `cron`、`timezone` | 持续触发，直到暂停、删除或 cron 不再有未来时刻 |

“多次定时”首版定义为同一 cron 的有限次数触发。需要多个不规则时间点时，可以创建多个 `once` 定时任务，不新增时间点数组语法。

次数统计按**已持久化接受的触发**计数，不按执行成功计数。执行失败、取消或交接中断仍消耗该次触发，避免失败导致无限重复执行。仅计算出的到期时刻、背压等待、离线跳过和重复投递不增加计数。

### 4.2 cron 格式

对外接受：

- 5 字段：`分 时 日 月 周`，规范化时在前面补秒 `0`。
- 6 字段：`秒 分 时 日 月 周`。
- 7 字段：`秒 分 时 日 月 周 年`，可指定绝对年份。

统一落盘为解析器接受的规范化格式。显式限制为上述字段数量，不静默猜测 Quartz 扩展或系统 crontab 的附加字段。库解析通过仍需验证至少存在一个未来时刻；失败返回 `invalid_cron` 或 `no_future_occurrence`。

复用本地已安装 `cron 0.16.0` 的 `Schedule::from_str` 和 `after` 能力。其 README 明确列出了秒到年的字段顺序；日与周组合、特殊字符和边界行为以该版本源码及实施时的契约测试为准，不宣称兼容所有 cron 方言。

### 4.3 时区与时钟

`timezone` 默认 `UTC`，支持 IANA 时区，例如 `Asia/Shanghai`。建议新增 `chrono-tz`；具体版本、与当前 chrono 的兼容性在实施时验证，本轮不修改依赖。

所有 `scheduled_at`、`next_fire_at`、更新时间持久化为 UTC；按用户选定时区解释 cron。查询和创建响应同时给出 UTC 时间与带偏移的本地时间，模型回复用户时应展示时区，避免把 UTC 当作本地时间。

夏令时策略：不存在的本地时刻跳过；重复的本地时刻选择较早的 UTC 时刻，只接受一次。实现需显式处理 `LocalResult`，若 cron 库的时区迭代不满足该契约，应在时间计算模块修正，不能只依赖库默认行为。

使用 `tokio::time::sleep_until` 等待最近 deadline，同时支持 CRUD 唤醒。建议最长每 30 秒重新对照墙上时钟计算等待，以处理系统时间调整和睡眠恢复；不为每个定时任务独立 spawn 一个常驻循环。时钟回拨不重发已接受的 UTC 时刻，时钟前跳走漏触发策略。

### 4.4 漏触发与执行重叠

漏触发支持 `coalesce` 和 `skip`，默认 `coalesce`：

- `coalesce`：恢复后，每个任务把漏掉的时刻合并为一次，取最近一个到期时刻；接受后从当前时间寻找下一次。
- `skip`：跳过漏掉的时刻，从恢复后的未来继续调度；过期的 `once` 结束并记录 `expired_skipped`。
- 首版不提供无限 catch-up。长时间离线不能逐个启动大量会话。

调度器保留一个每任务的待接受槽位。执行重叠首版采用 `queue_one`：同一任务最多一个执行中的 occurrence 和一个待处理时刻；后续到期时刻合并进该槽位，保留最近时刻。没有开始交接前，该槽位不是已接受 occurrence，不消耗次数。前一次终态后，才接受下一次并生成 Event。

这意味着“每分钟执行 3 次”在执行慢于一分钟时，3 次不会同时运行，实际启动时间可能延后。定时器保证 cron 到期判定和有限次数上限，不保证在资源不足时恰好于墙上时钟启动 Agent。

## 5. 数据契约与持久化

### 5.1 定时定义与归属

建议 `TimerDefinition` 包含：

| 字段 | 说明 |
| --- | --- |
| `id`、`revision` | 不复用的 UUID、乐观并发版本 |
| `owner` | `agent_id`、`user_id`，只能来自 `ctx.scope()` |
| `created_session_id` | 创建会话 ID，仅用于追踪，不作为执行目标 |
| `execution_binding` | 可信来源解析得到的 Agent 来源、绝对工作区；不保留活跃 Context |
| `name`、`input` | 展示名称和到期执行的用户任务文本 |
| `schedule` | once / repeat / loop、规范化 cron、timezone |
| `misfire_policy` | coalesce / skip |
| `state`、`completion_reason` | active / paused / completed / deleted 及原因 |
| `accepted_count`、`next_fire_at` | 已接受次数和下次 UTC 时刻 |
| `created_at`、`updated_at` | UTC 时间 |
| `last_occurrence_id` | 最近一次触发关联 |

首版任务输入只接受非空文本，执行模式固定为 `chat`。不保存整段旧会话、图片、附件或 prompt 快照；新会话加载该用户的已有记忆，历史仅来自新 session。

Agent 来源保留 `SingleAgentSource::AgentId` 或 `Paths`。每次触发重新加载并冻结当前配置和 prompt，校验配置的 Agent 名称等于保存的 `owner.agent_id`；配置中的 user 和默认 session 不能覆盖任务归属。工作区使用创建时的绝对路径，并在触发时再次检查存在且为目录。来源丢失、Agent 改名或工作区无效时记录失败，不回退到其他 Agent、默认用户或当前服务目录。

### 5.2 可信执行绑定

由于现有 ContextScope 不包含来源与工作区，新增可供宿主注册的 `TimerExecutionBindingResolver`。它接收 `ctx`，返回该执行已绑定的来源和工作区，必须同时校验结果的 Agent/User 与 scope 一致。

服务在创建 Actor、启动每次执行以及构建子 Agent Plan 时注册绑定。单 Agent 构建器已掌握真实来源；可在构建阶段通过轻量宿主接口注册当前 execution scope 的绑定，任务子 Context 通过 parent linkage 查找该绑定。子 Agent 必须注册自身来源，不能把父 Actor 的 Agent 来源错误地绑定给子 Agent。子 Agent 工作区继承已绑定工作区。

绑定存储随执行清理，定时创建时复制需要的可序列化字段。查不到绑定时创建操作返回 `execution_binding_unavailable`。查询、删除和暂停等仅需归属的操作仍可执行。此接口补充执行环境，不承担改写用户身份的职责。

### 5.3 触发记录

`TimerOccurrence` 与定时定义分开建模，包含：

- `occurrence_id`、`timer_id`、`definition_revision`。
- 保存的执行参数快照、owner、`scheduled_at`、`emitted_at`。
- 首次接受时生成的 `session_id`，后续投递保持相同。
- `status`、启动时间、完成时间、错误码和简短错误说明。
- 可选 `round_id`、结果摘要或会话文件关联，不默认复制完整模型输出。

触发状态：`pending → dispatching → running → succeeded / failed / cancelled`；重启发现 `dispatching` 或 `running` 无法确认完成时，置为 `interrupted`。删除前尚未交接的 pending 记录置为 `suppressed`。

定时定义的 `completed` 表示不再接受未来触发，不表示最后一次 Agent 已执行成功。工具响应分别展示定义状态和最近 occurrence 状态。

### 5.4 存储布局与事务

建议独立于 session history 保存：

```text
<fae home>/
  timer/
    <agent_id>/
      <user_id>/
        state.json
```

`state.json` 包含 `schema_version`、定时定义、触发记录和创建幂等键。定义更新、计数增加、下次时间推进和 occurrence 创建必须在同一次分区提交中完成，避免多文件更新导致重启重复接受。

复用项目路径片段校验，验证文件内容中的 owner 与路径一致。同 home 的后台服务依靠已有 `server.lock` 单写；Runtime 内串行化每个分区事务。嵌入式宿主须取得该 home 的独占调度锁，不能与后台服务同时写同一存储。

写入采用同目录临时文件、flush/sync、原子替换，在支持的系统上同步父目录；IO 放在阻塞线程中。实施时验证 macOS、Linux 和 Windows 的替换行为。存储失败时不能先发 Event 或向模型报告创建成功。未知 schema 使初始化失败；单分区损坏隔离并报告错误，不静默把损坏文件覆盖为空状态。

建议默认每个 Agent/User 最多 100 个未删除定义，服务最多 1000 个；终态触发记录保留最近 1000 条或 30 天，pending/running 永不因保留策略删除。压缩终态记录时保留任务触发水位与必要幂等信息，防止时钟回拨或重投产生旧任务。

会话 `clean` 继续处理 history 和 todo，不隐式删除独立定时定义。显式删除定时器使用 `timer delete`；文档应提醒清理会话后定时任务仍然有效。

## 6. Runtime 与 Event 接口

### 6.1 类型化管理接口

建议管理代理实现：

```rust
RuntimeSelectExec<TimerRequest, TimerResponse, TimerQuery, TimerList>
```

Runtime ID 为 `timer`，支持 `TaskType::Any("timer".into())`。`TimerRequest` 使用 enum 表达 `Create`、`Query`、`Update`、`Delete`，由 Runtime 内部再次检查 Context 归属，不能只信任 Tool 已校验。

`TimerTool::exec(ctx, req)` 解析 JSON 后，通过 `ctx.get_engine().rt().exec(...)` 调用上述 Runtime。请求的 `TaskMeta.executor` 指定 `timer`，仍走 EngineRuntime 现有路由与 hook 组合。立即返回 CRUD 结果，不把一次工具调用挂起等待到期。

真正的 TimerRuntime 持有共享管理服务并实现 `watch()`；每会话的 TimerClientRuntime 只实现管理接口。两者共用管理契约，但只有服务级对象启动 scheduler。

### 6.2 到期 Event

建议采用以下表达方式；这是接口示意，并非本轮新增代码：

```rust
Event {
    from_rt_id: "timer".to_owned(),
    event_type: EventType::Any(
        "timer".to_owned(),
        Box::new(TimerFired {
            timer_id,
            occurrence_id,
            definition_revision,
            owner,
            session_id,
            scheduled_at,
            emitted_at,
        }),
    ),
}
```

`TimerFired` 定义于 `fae-agent`，字段为类型明确的结构；Dispatcher 校验 `from_rt_id` 和消息类型，再按 `occurrence_id` 从存储读取可信执行快照。Event 本身不携带旧 Context、完整 prompt 或整个定时输入。

当前 `EventType::Any` 的字符串会被 `EngineRuntime::trigger` 当作 Runtime 路由 ID，不是事件名称。这里使用 `timer`；Dispatcher 直接消费专用事件流，不调用 `engine.trigger(event)` 自动执行。

接受触发时先提交 occurrence，再投递 Event。事件队列满或消费者暂时不可用时保留 pending，后续按相同 `occurrence_id` 重投。Event 已发出不等于新会话已启动，也不等于任务执行成功。

## 7. timer 工具

工具名为 `timer`，由 `DefaultTools` 聚合；Agent 的 `tools` 配置中显式列出 `"timer"` 才能调用。新增到初始化模板与默认工具列表，使新建 Agent 可用；旧配置不自动修改。

使用 `operation` tag 和 `deny_unknown_fields`；参数中不允许 `user_id`、`agent_id`、`session_id`、`source`、`workspace` 或任意外部动作。错误工具名仍按项目现有协议错误反馈机制处理，不为 `timer_create` 等名称新增别名。

| 操作 | 必需字段 | 可选字段与行为 |
| --- | --- | --- |
| `create` | `name`、`input`、`schedule`、`idempotency_key` | `misfire_policy`；创建后启用并返回后续触发预览 |
| `query` | 无 | `id`、`state`、`limit`、`cursor`、`include_occurrences`；默认仅当前归属，分页上限 100 |
| `update` | `id`、`expected_revision` | `name`、`input`、完整 `schedule`、`misfire_policy`、`enabled`；至少一个变更 |
| `delete` | `id` | `expected_revision`；保留 tombstone，重复删除返回已删除状态 |

`idempotency_key` 由调用方为一次创建生成，同一 Agent/User 内相同 key 与相同参数返回同一定时定义；相同 key 与不同参数返回 `idempotency_conflict`。工具 schema 和说明须指导模型重试沿用 key。用户再次明确创建另一个相同任务时使用新 key。

修改规则：

- 暂停不重置计数，恢复使用当前时间和漏触发策略重新计算下一次。
- 更新 schedule 替换整个 schedule 对象，不采用可能产生非法组合的局部嵌套 patch。
- 已接受 occurrence 的输入快照不可被 update 改写；新的定义只影响尚未接受的触发。
- 更新总次数时不得低于 `accepted_count`；等于当前计数则立即结束未来调度。
- 已 completed 或 deleted 的定义不能重新启用；重新创建使用新 ID。
- 删除抑制尚未交接的 pending；已 running 的 session 默认继续完成。删除不是取消会话。

创建示例，时区和日期为说明语义的示例参数：

```json
{
  "operation": "create",
  "idempotency_key": "daily-project-summary-20261105",
  "name": "每日项目摘要",
  "input": "检查当前工作区的变更，生成今日项目摘要。",
  "schedule": {
    "kind": "loop",
    "cron": "0 0 9 * * *",
    "timezone": "Asia/Shanghai"
  }
}
```

其他 schedule 示例：

```json
{"kind":"once","cron":"0 30 18 6 11 * 2026","timezone":"Asia/Shanghai"}
```

```json
{"kind":"repeat","cron":"0 */10 * * * *","timezone":"Asia/Shanghai","max_fires":3}
```

成功响应包含 `id`、`revision`、owner、schedule、定义状态、计数、下一次触发时间与最多 3 个未来时刻预览。查询可返回最近 occurrence 的状态及新 session ID，便于继续查看执行结果。

业务错误以结构化 JSON 放入现有 `ToolResponse` 错误响应，包含稳定 `code` 和可读 message。主要错误包括 `invalid_cron`、`invalid_timezone`、`no_future_occurrence`、`timer_unavailable`、`execution_binding_unavailable`、`timer_not_found`、`revision_conflict`、`idempotency_conflict`、`resource_exhausted`。访问其他归属的 ID 与不存在的 ID 同样返回 `timer_not_found`。

## 8. 到期后启动新 session

### 8.1 内部会话入口

新增 `Registry::open_internal_agent`，接受由服务存储读取的 owner、来源、工作区、新 session ID 和 occurrence 关联，不要求 `Outbound`。复用普通 `open` 的配置加载、路径校验、Key 构建、会话配额和 Actor 创建逻辑，避免维护两套会话实现。

内部入口禁止恢复原 session，禁止读取 Agent 配置中的默认 user/session 作为执行归属。`Key` 固定为：

```text
kind = agent
target = timer.owner.agent_id
user = timer.owner.user_id
session = occurrence.session_id
```

Actor 新增内部启动命令和来源信息；默认 `out = None`、没有客户端 lease。先复用 `reserve_round` 获得并发配额，执行完及时释放后台 Actor，session history 继续持久化。需要在线查看时允许正常客户端附着，受现有单客户端 lease 规则约束；已释放 Actor 则按保存的新 session ID 打开历史。

不能构造一个无人读取的假 Outbound，否则容易积压输出或产生错误 lease 状态。现有 Actor 已能在断线时收集输出和终态，该路径应复用。

### 8.2 显式 Context 绑定

使用 `SingleAgentEnv::new_with_user_id(source, input, owner.user_id)`，并显式 `.with_session_id(occurrence.session_id)`。新增一个支持已绑定 root Context 的 Engine 启动入口，例如 `launch_with_scope`；内部复用 `Engine::call` 和现有 `run_plan` 路径，继续执行 plan hooks、状态更新和终态处理。

在构建 Plan 前把新 `CommonSession`、owner.user、owner.agent 绑定到独立 `ContextScope`。新 Context 的 `parent_scope_id` 为空；定时来源以 occurrence 关联记录，不 fork 创建定时任务的旧 Context，避免继承旧对话的终态或取消。

单 Agent 构建器再次校验 scope、env 与加载配置一致。会话身份显式绑定后，工具、workflow input、config 或 hook 不得覆盖它。

### 8.3 输入与结果

将保存的 `input` 作为新会话的 `SessionInput::NewChat`。通过提示词 hook 补充英文 `<TimerTrigger>` 元数据，包含 timer ID、occurrence ID、计划时间和实际触发时间；元数据不包含执行权限或可覆盖身份的指令。

运行时照常加载用户记忆、Agent prompt 和工作区文档，新 session 不注入旧 session 的对话历史。输出和错误走现有 `SessionOutput`、`RoundOutcome`；Dispatcher 将终态映射回触发记录。

首版不把结果自动发送到创建任务的旧 TUI，不新增外部通知渠道。用户通过 `timer query` 获取执行状态和 session ID，再访问现有 history 能力查看会话内容。

## 9. 交接一致性、失败与资源限制

### 9.1 单次交接流程

1. Scheduler 在分区事务中确认到期、次数和定义状态，生成 occurrence/session ID，增加计数并推进下次时间，提交 pending。
2. 发送 `TimerFired`，Dispatcher 按 occurrence ID 幂等读取。
3. 申请现有会话与回合配额；资源不足时保留 pending，释放临时预留，不进入执行。
4. 在同一个存储事务中校验任务未被删除、occurrence 仍 pending，然后置为 dispatching。
5. 内部 Actor 使用已保存的新 session ID 启动；确认后置为 running。
6. 收到终态后写入 succeeded/failed/cancelled，释放配额和该任务执行占用。

CRUD 删除与第 4 步串行化：删除先提交则不得启动；dispatching 先提交则视为已经交接，删除不承诺终止该执行。重复 Event 看到 dispatching/running/terminal 时不再启动。

### 9.2 崩溃恢复边界

本方案保证可去重的 Event 投递和有界执行交接，不承诺跨进程故障下的“模型及外部工具恰好执行一次”。

- pending：尚未交接，可以重投同一 occurrence。
- dispatching：可能在落盘后尚未 launch，也可能已经 launch 但未确认；重启置 interrupted，不自动重跑。
- running：服务进程退出后不认定成功，重启置 interrupted，不自动重跑。
- terminal：保持终态，不因收到旧 Event 被改写或重跑。

这是优先避免副作用重复的策略，代价是交接窗口崩溃可能漏执行。用户需要重试时明确创建一个新的 once 任务；不要复用旧 occurrence。若后续要求可靠自动重跑，需引入执行 lease、启动恢复协议及业务工具幂等契约，再单独设计。

执行失败或取消不自动重试模型整轮；仍遵循项目现有模型调用重试边界。循环任务的后续触发不受前一次普通执行失败影响。存储不可写时停止接受新触发，不能继续执行后再补状态。

### 9.3 背压与公平性

定时会话共享当前 8 个活跃回合和 32 个保留会话配额；建议定时执行自身并发上限为 2，待交接 occurrence 队列上限为 256。这些是首版建议值，应集中定义，避免散落 magic numbers。

按 owner 轮转、owner 内按 scheduled_at 排序。资源不足时在回合完成通知或有界重试时唤醒，不忙轮询。队列容量达到上限时不创建新 occurrence、不增加次数，保留每任务一个待接受时刻并合并后续时刻。全部队列等待都不持有文件事务锁。

会话清理期间 `begin_clean` 阻止同 Agent/User 的执行交接，pending 等待后恢复，不绕过维护锁。定时会话运行中也必须被 Registry 的 active 计数纳入，以免清理与执行并发。

## 10. 实施顺序与改动清单

本节仅用于后续实施，本轮不执行。

1. **公共契约与时间语义**：新增 timer 类型和 Runtime 管理契约；规范化 cron、时区、有限次数和漏触发语义。
2. **持久化与调度器**：实现分区事务、唤醒、pending/outbox、恢复、计数上限和单消费者事件流。
3. **工具与管理代理**：新增 TimerTool、TimerClientRuntime，接入 DefaultTools；更新 `fae init`、Agent 示例和工具说明。
4. **可信执行绑定**：在服务、单 Agent 构建与子 Agent 路径注册来源/工作区绑定，确保任务子 Context 可解析、执行结束可释放。
5. **服务内新会话分发**：新增无客户端 Registry 入口、内部 Actor 命令、显式 scope 启动和 occurrence 回执，共用原资源限制。
6. **生命周期与验收**：启动恢复、关闭顺序、错误可见性、历史读取与回归验证；更新 `app/fae/README.md`。

除新增模块外，预计修改：

- `crates/fae-agent/src/lib.rs`、`plan/single_agent/builder.rs`：类型导出、可信绑定注册。
- `crates/fae-engine/src/lib.rs`、`engine_rt/mod.rs`、`tools/mod.rs`：Runtime 与 Tool 导出/注册。
- `crates/fae-engine/src/engine/engine.rs`：复用执行路径的显式 scope 启动能力。
- `crates/fae-engine/Cargo.toml`：实施时加入并验证时区依赖。
- `app/fae/src/server/mod.rs`、`engine.rs`、`registry.rs`、`session.rs`、`init.rs`：共享服务、内部启动与默认配置。
- `app/fae/tests/service.rs` 及相关模块测试：服务与重启场景验收。

默认不改变 WebSocket v1 的 envelope 或现有 Event 输出结构。首版通过 timer 工具返回状态和新 session ID；若后续新增原生 CLI 定时管理或主动通知，再扩展 control 协议。

## 11. 验收标准

| 场景 | 预期结果 |
| --- | --- |
| once | 首个匹配时刻生成一个 Event，启动一个新 session，不再接受第二次 |
| repeat N | 接受 N 次触发，各自独立 session，失败不额外增加重试触发 |
| loop | 持续按 cron 判定到期，暂停/删除后停止接受新触发 |
| 五/六/七字段与无效 cron | 正确规范化或返回明确错误；没有未来时刻不能创建 |
| 时区、夏令时、时钟回拨/前跳 | 满足选定契约，同一计划时刻不重复接受 |
| 多会话 Engine 构建/释放 | 服务仅有一个调度器和一个事件消费者，释放任一 Engine 不停止它 |
| CRUD 并发与幂等 | revision 冲突可见；相同幂等键不创建重复定时 |
| 用户/Agent 隔离 | Tool 与 Runtime 双重校验，外部参数不能改变归属 |
| 子 Agent 创建定时 | 使用子 Agent 自身来源和原用户，不错误落到父 Agent |
| 新 session | 每个 occurrence 新 ID，原 session 结束或取消不影响后续触发 |
| 配置身份变更 | user/default session 不覆盖保存归属；Agent 改名或来源失效明确失败 |
| 无客户端运行 | 不需要 Outbound，输出正常消费，终态和 history 可查询 |
| 删除与到期竞争 | 未交接的 pending 被抑制；已交接任务按既定规则结束 |
| 重启与崩溃窗口 | pending 重投不产生重复 session；dispatching/running 转 interrupted |
| 队列满、长时间离线、慢执行 | 有界合并与背压，不出现无限 catch-up 或并发放大 |
| 存储错误与会话清理 | 先落盘后 Event；错误不报告成功，维护锁不被绕过 |

后续实施需要采用可控时钟、短路径故障注入与 fake Agent，验证时间、存储和交接契约；服务测试覆盖停止/重启和无客户端会话。使用 `cargo fmt --all -- --check`、`cargo check --workspace --all-targets` 与相关测试验证，真实模型和 TUI 验收单独列出，不能以编译通过替代。

## 12. 方案边界与评审重点

本方案完整覆盖 cron 定时 Runtime、Agent 可调用的 CRUD 工具，以及到期后原用户/原 Agent 的新 session 执行。实施前重点评审以下已给出默认值的选择：

- 多次定时按“同一 cron 的有限次数”定义，计数按持久化接受而非成功执行。
- 默认 UTC，显式支持 IANA 时区；漏触发默认合并一次。
- 同任务采用 queue_one，不允许默认并行重叠。
- 新会话加载最新配置并冻结，用户、Agent 和工作区归属保持固定。
- 已交接记录故障后不自动重跑，优先避免重复副作用。
- 普通 session clean 保留定时任务，删除定时不取消已交接会话。

这些选择可以在评审时调整；文档未要求本轮开始实施。
