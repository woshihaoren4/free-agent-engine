# FAE 飞书智能体消息收发方案

状态：首版已实现；真实飞书部署验收待执行。  
日期：2026-11-08。  
范围：以 `app/fae/src/lark/` 为飞书交互入口，复用现有 FAE 后台服务执行 single agent。

## 1. 目标与设计结论

用户向飞书应用机器人发送消息后，FAE 立即给原消息添加“敲键盘”表情，调用配置的 Agent，并将模型正文和最终结果回复到原聊天中。

采用以下设计：

1. 使用 `larksuite-oapi-sdk-rs` 的 WebSocket 长连接接收 `im.message.receive_v1` 事件，使用同一个 SDK 调用 IM、表情和 CardKit API。
2. `lark/` 与 `tui/` 同属交互适配层。Lark 不直接创建 Engine，不另建模型、工具、记忆和历史运行时；通过本机 WebSocket 调用 `server/`。
3. 一个 `fae` 可执行文件支持不同进程角色：TUI 客户端、Agent 后台服务、Lark 网关。Lark 网关是独立进程，仅在显式执行 `fae lark start` 时启动。
4. 每次模型响应的可见正文对应一条独立卡片消息。带工具调用的响应作为中间消息；最后一次响应使用 CardKit 实时流式更新，并在 Agent 整轮结束后确认成功或错误。
5. 飞书 `sender.sender_id.user_id` 原值绑定为 Agent `user_id`；稳定的 `session_id` 包含应用、租户、用户和聊天维度。同一个人的单聊、不同群聊互不串历史，同一个群内不同用户也互不串历史。
6. 配置统一保存到 `<FAE_HOME>/lark.config`，默认 `~/.fae/lark.config`。配置存在不代表自动启动。

“飞书智能体”在本方案中指具有机器人能力、开放平台消息事件和收发权限的**企业自建应用机器人**。首版采用官方长连接适用的企业自建应用形态；商店应用、独立平台智能体专用接口、Webhook 接入不纳入首版。

## 2. 与现有实现的关系

现有代码已经具备：

| 文件 / 模块 | 当前能力 | 本方案如何使用 |
|---|---|---|
| `app/fae/src/app/client.rs` | 每个 session 一条双向连接、服务发现、断线 resume | 抽取或扩展为 TUI/Lark 共用客户端 |
| `app/fae/src/protocol/session.rs` | Open/Input/Cancel、Event、Finished、RoundOutcome | 增加显式身份绑定和模型响应边界 |
| `app/fae/src/server/registry.rs` | 按 target/user/session 注册 actor | 完整身份键查找，避免跨用户复用 actor |
| `app/fae/src/server/session.rs` | Agent 执行、ContextScope、回合取消和事件重放 | 保持唯一执行入口 |
| `crates/fae-agent/src/plan/single_agent/execution/response.rs` | 模型正文 delta、推理内容、工具调用和最终输出 | 增加每次模型响应的开始/结束事件 |
| `crates/fae-agent/src/session/mod.rs` | 统一 SessionOutput / SessionEventData | 承载响应 ID 和边界信息 |

两处现有能力不能直接满足需求，实施时必须调整：

- `OpenSession` 目前没有显式用户身份，Registry 从 Agent 配置取 `config.agent.user_id`。仅给飞书生成不同 session ID，不能满足“飞书用户作为 Agent 用户”的要求。
- `ModelOutput` 的正文可能是流式 delta，但没有模型响应 ID 或“是否还要调用工具”的结束事件。`turn_id` 是 Agent 对话回合，不是该回合中每一次模型请求，不能用它切分中间消息。

复用架构基于 [FAE 服务常驻与 TUI 分离方案](./fae-daemon-service.md)，本文件描述拟增加的能力，不代表这些扩展已存在。

## 3. 进程与模块结构

```mermaid
flowchart LR
    U[飞书用户 / 群聊] -->|消息事件| F[飞书开放平台]
    F -->|SDK 长连接| L[fae lark 网关进程]
    L -->|SDK 表情 / IM / CardKit API| F
    L -->|认证后的本机 WebSocket| S[fae server]
    T[TUI 客户端] -->|本机 WebSocket| S
    S --> A[Agent / 模型 / 工具]
    A -->|结构化事件 / 终态| S
    S -->|事件流| L
    F -->|中间消息 / 流式回复 / 错误| U
```

拟定目录：

```text
app/fae/src/lark/
├── mod.rs          # 网关组装与运行入口
├── config.rs       # lark.config 读取、默认值、校验和脱敏展示
├── lifecycle.rs    # 独立网关进程 start/stop/status、锁和健康状态
├── sdk.rs          # SDK client、事件订阅、表情/回复/CardKit 封装
├── inbound.rs      # 事件过滤、文本解析、mention 处理
├── identity.rs     # 飞书身份与稳定 session 映射
├── session.rs      # session worker、串行队列、服务连接和取消
├── output.rs       # 可见事件筛选、模型响应到消息的状态机
├── card.rs         # 卡片创建、全文更新、序号和终态收尾
└── store.rs        # 消息去重、收发记录、断线与进程恢复状态
```

命令解析和分发仍放在 `app/args.rs`、`app/mod.rs`。未来可将 `app/client.rs` 抽到公共 `client/`；首版也可共享现有模块。`server/` 只新增通用身份、事件和请求幂等能力，不依赖飞书 SDK。

SDK 拟使用研究时的 `0.3.13` 版本，启用 `ws` feature，普通 typed IM 和 CardKit 接口按其公共 API 使用。该版本为非官方 Rust SDK，声明最低 Rust 版本为 1.95.0；当前环境为 `rustc 1.95.0`。实施时需锁定依赖并核对所有构建目标，不在本设计阶段修改 Cargo 文件。

SDK 的 token 缓存、认证、协议 framing 和长连接重连由 SDK 管理；网关负责业务去重、用户会话、消息投递和限流。未覆盖的端点也应通过该 crate 的 raw request 能力封装，避免引入另一套收发 SDK 或认证实现。

## 4. 飞书应用设置与权限

飞书侧需要：

- 开启机器人能力，发布应用并设置用户可用范围。
- 订阅 `im.message.receive_v1`（控制台中的接收消息 v2.0），选择长连接接收事件。
- 将机器人加入需要交互的群聊。

首版使用应用身份 `tenant_access_token` 收发，不需要用户 OAuth 登录。

| 权限 | 用途 |
|---|---|
| `im:message.p2p_msg:readonly` | 接收用户发给机器人的单聊消息 |
| `im:message.group_at_msg:readonly` | 接收群内用户 @ 机器人的消息 |
| `im:message:send_as_bot` | 以机器人身份回复消息 |
| `im:message.reactions:write_only` | 添加和删除“敲键盘”表情 |
| `cardkit:card:write` | 创建卡片、流式更新文本、关闭流式模式 |
| `contact:user.employee_id:readonly` | 让事件提供 `sender_id.user_id` |

如当前平台的卡片接入要求同时开通 `im:message`，按官方卡片指南及实际 API 授权要求补齐；不申请接收群内所有消息的权限。

群聊默认只处理 @ 当前机器人的用户消息，单聊处理所有用户文本消息。必须校验 `sender_type == "user"`，忽略机器人消息和自身输出，防止循环调用。识别 @ 机器人使用事件 `mentions` 和机器人自己的 open ID，不通过正文显示名判断；机器人 open ID 在启动时通过 SDK 的机器人信息接口获取并缓存。

## 5. 用户、session 与执行 ID 映射

### 5.1 身份定义

首版一个 FAE home 只绑定一个飞书应用及一个企业租户。`tenant_key` 为必填配置；网关只接受该租户内部用户，跨租户事件明确拒绝。

| 标识 | 来源 / 计算方式 | 用途 |
|---|---|---|
| `app_id` | `lark.config` 中的应用 App ID | SDK 凭证和网关命名空间 |
| `tenant_key` | 配置值与可信事件的租户值校验 | 限定身份域 |
| `lark_user_id` | `event.sender.sender_id.user_id` | **原值作为 Agent `user_id`** |
| `open_id` | `event.sender.sender_id.open_id` | 飞书 @、展示等 API 用途，不替换 Agent 身份 |
| `chat_id` | `event.message.chat_id` | 回复目标、会话划分 |
| `chat_type` | `p2p` / `group` | 区分聊天类型 |
| `message_id` | `event.message.message_id` | 业务去重和本轮回复锚点 |
| `event_id` | 事件头 | 日志关联，不作为消息去重依据 |
| `agent_id` | 配置的 Agent source ID | 服务加载 Agent |
| `target_id` | 服务加载后返回的实际 Agent 身份 | 服务 actor 和持久化分区 |
| `session_id` | 下述稳定算法 | Agent 会话历史分区 |
| `round_id` | 服务接受 Input 后分配 | 一条用户消息对应的一次执行 |
| `stream_id + seq` | 服务事件流 | 重连、事件重放去重 |
| `response_id` | Agent 每次模型调用分配 | 区分同轮多个模型响应 |
| `card_id` / `reply_message_id` | 飞书 API 返回 | 更新卡片和记录消息投递 |

不能用群 ID 作为 `user_id`，不能用 `message_id` 作为长期 `session_id`，不能从消息正文或工具参数读取身份。

严格使用 `user_id` 的代价是必须申请对应字段权限。若事件没有该字段，回复“无法识别飞书用户，请管理员检查 user ID 权限”，不调用 Agent，也不静默回退到 `open_id`、`union_id` 或 `master`。

租户校验同时检查消息发送者租户和事件应用上下文；涉及外部群、外部用户时，只接受配置租户内的发送者。若无法可靠确认，拒绝绑定身份。多租户支持需另行引入 namespaced user 或 tenant scope，不能直接把不同租户的裸 `user_id` 混入同一个 home。

### 5.2 稳定 session 算法

定义 canonical tuple，使用固定顺序的 JSON 数组编码：

```text
["fae-lark-session-v1", app_id, tenant_key, lark_user_id, chat_type, chat_id]

session_id = "lark-v1-" + lowercase_hex(SHA256(canonical_tuple))
```

版本前缀和完整哈希确保路径安全、稳定和可升级；持久化记录保存原 tuple，读取时校验映射，不能只保存哈希而丢失对应关系。`agent_id` 由服务 target 维度隔离，无须重复放入 session 哈希。

| 场景 | Agent user | Agent session |
|---|---|---|
| 用户 U 与机器人单聊 | U 的飞书 `user_id` | H(app, tenant, U, p2p, chat_P) |
| 用户 U 在群 G1 交互 | 同一个 U | H(app, tenant, U, group, G1) |
| 用户 U 在群 G2 交互 | 同一个 U | H(app, tenant, U, group, G2) |
| 用户 V 在群 G1 交互 | V 的飞书 `user_id` | H(app, tenant, V, group, G1) |

首版同一用户在同一聊天内的不同话题共用 session；`thread_id/root_id/parent_id` 只用于回复定位，不参与 session 哈希。每轮输出回复该轮输入的 `message_id`，若输入已经位于话题，按飞书 reply API 规则留在原话题。普通群聊默认不主动创建新话题。

### 5.3 持久化与共享边界

历史使用现有分区：

```text
<FAE_HOME>/session/<actual-agent-id>/<lark-user-id>/<session-id>.jsonl
```

同一用户不同聊天的历史、活动 round、输出缓冲、连接和取消互相隔离。显式身份写入 `ContextScope`，子 Agent 通过 child context 继承用户身份。

**用户记忆仍按用户共享**：现有 `<FAE_HOME>/memory/<user_id>.jsonl` 是用户长期记忆，不是 session 历史。因此同一用户的单聊和群聊可共享用户记忆。session 隔离不等于共享工具资源或记忆完全隔离；在群内发送回复也仍对群成员可见。

**Todo 是需要补齐的隔离点**：现有 `<agent>/<user>/todo.json` 是跨 session 共享文件。Lark 并发 session 若开放 todo 工具，需为 Lark 绑定的 context 选择 session 级 todo 存储，例如 `<agent>/<user>/<session-id>/todo.json`，并让子执行继承原始 todo 所属 session。通过通用 scope 中的工具状态分区策略实现，不在工具里识别飞书 ID 字符串。TUI 原有默认策略保留。该扩展实施前，Lark 启动检查拒绝使用包含共享 todo route 的 Agent，不能宣称仅靠会话哈希实现了工具状态隔离。

命令、文件操作等工具仍作用于配置的工作区；首版所有 Lark 用户可共用同一工作区，文件系统并不因此隔离。需要文件隔离的部署应显式配置独立工作区策略，不能把 session 隔离当成执行沙箱。

## 6. 服务身份绑定与协议扩展

### 6.1 打开会话

拟在 `OpenSession` 增加可选的结构化 `binding`：

```text
binding:
  channel: lark
  user_id: <sender_id.user_id>
  channel_identity:
    app_id, tenant_key, chat_type, chat_id
```

Lark 模式该字段必填，`session_id` 也必填。协议扩展升级版本为 v2，通过 hello 检查版本，不兼容时明确要求重启服务。

服务使用经过认证的网关 principal 处理绑定。拟增加独立 `<FAE_HOME>/lark.token`，只允许本机连接 `/v2/lark/session`，不可调用 shutdown/init 等管理接口；TUI 继续使用 `server.token` 和普通 session 路由。token 由服务创建、限制本地文件权限，网关读取后连接；它不放入飞书配置，也不发给模型或用户。

Lark route 的信任模型是“已认证的本地网关验证 SDK 事件，再向服务声明身份”，不是服务重新验证飞书事件。持有网关 token 的本地进程属于可信边界。服务仍须：

1. 从本地配置读取允许的应用、租户、Agent 和 workspace，校验 binding 和 Open target。
2. 根据 binding 重新计算 session ID，验证与请求一致，并校验 user/session 路径。
3. 在 actor 查找前解析完整 `(kind, target, user, session)`，不沿用只按 target/session 搜索的快捷路径。
4. resume 同时校验已绑定身份和 stream 所属 key，不允许凭一个 stream ID 跨用户恢复。
5. 创建 `ContextScope::root(user_id)`，绑定 agent/session，并把 scope 作为执行身份的唯一来源。
6. 配置文件中的默认 `agent.user_id` 不能覆盖显式 binding，后续 Input、工具参数和 hooks 也不能改变身份。

普通 TUI 请求没有 binding 时保留现有默认身份行为；binding 只在会话建立时确定，不能每轮修改。

### 6.2 输入与幂等

每条新用户消息在对应 session worker 中提交一次 `SessionInput::NewChat`，沿用会话历史；这里的 NewChat 表示开始新的执行回合，不表示清空历史。首版不自动把执行中的新消息作为 Supplement，而是排队成为下一轮。

为 Input 增加 `external_request_id`，值为应用/租户/message ID tuple 的哈希。服务将该值与完整 session key、输入摘要、round ID、接受状态绑定，并提供查询接口。相同 ID/相同摘要返回原接受结果；相同 ID/不同内容报冲突。

提交前网关记录 `Submitting`；服务记录接受关系后再 Ack。断线导致接受结果未知时，先查接受记录或恢复原 stream，禁止换 request ID 重新调用 Agent。进程重启后的“执行记录不完整”归为不确定状态，通知用户重新发起，不自动重跑可能已经产生工具副作用的请求。

首版承诺有界去重和不盲目重复执行，不承诺外部工具副作用与本地记录之间的事务性 exactly-once。

## 7. 接收消息与立即反馈

```mermaid
sequenceDiagram
    participant U as 飞书用户
    participant L as Lark 网关
    participant F as 飞书 API
    participant S as FAE 服务
    participant A as Agent
    U->>L: im.message.receive_v1
    L->>L: 校验、message_id 去重、落盘
    L-->>U: SDK 事件确认
    L->>F: 原消息添加 Typing 表情
    L->>L: 用户/session worker 排队
    L->>S: Open(binding) / Input
    S->>A: 绑定 ContextScope 执行
    A-->>L: 模型正文与响应边界（经服务）
    L->>F: 独立中间消息 / 流式卡片
    A-->>S: 整轮成功或错误
    S-->>L: Finished
    L->>F: 最终收尾 / 错误消息
    L->>F: 删除本轮 Typing 表情
```

图中的 SDK 确认是传输确认；“敲键盘”才是用户可见反馈，两者不能混为一谈。

接收回调只做快速校验和持久化入队，不等待 Agent，也不等待飞书发送 API 完成。官方长连接处理有 3 秒响应窗口，callback 必须在此窗口内返回；持久化失败或入口队列无法接受时返回 SDK 错误，不静默确认后丢失。

对已确认处理的消息，由高优先级反馈任务立刻调用：

```text
POST /open-apis/im/v1/messages/{message_id}/reactions
reaction_type.emoji_type = "Typing"
```

枚举大小写必须是 **`Typing`**。保存返回的 `reaction_id`，终态或拒绝后删除自己添加的表情。反馈任务独立于 Agent 并发名额和 session 队列，因此排队中的消息也能及时得到表情。

“立即”定义为事件可靠接收后立即调度，不等待模型首 token；目标正常网络下 1 秒内发起 API 请求，不把平台/网络延迟当作可保证 SLA。表情失败有界重试并记录，不永久阻塞 Agent。重复推送不会重复启动 round；已有 reaction ID 时复用记录。

首版支持 `text`：解析 content 中的 JSON text，移除对当前机器人的 mention 占位符，保留其他 mention 的可读信息，不直接删除所有 `@_user_*`。空文本或不支持的消息类型回复说明并结束，不调用 Agent。图片、文件、语音下载及多模态输入作为后续扩展。

## 8. 模型输出与飞书消息状态机

### 8.1 可见事件规则

| 事件 / 结果 | 飞书行为 |
|---|---|
| 顶层 Agent 的模型正文 | 按 response ID 生成独立回复消息 |
| 正文 + 工具调用 | 保留为该次响应的中间消息 |
| 只有工具调用、没有正文 | 不创建空消息 |
| ToolCall / ToolOutput / 工具参数和结果 | 不发送 |
| ModelReasoning | 不发送 |
| 压缩、计划、内部节点等事件 | 不发送 |
| 子 Agent 的内部输出 | 首版不发送，由顶层 Agent 整理后回复 |
| `Completed` / `Finished::Succeeded` | 校对最终正文、收尾现有卡片，不重复发送正文 |
| `Finished::Failed` | 发出含具体错误的 `ERROR` 消息，部分输出标记失败 |
| `Finished::Cancelled` | 发出“本次执行已取消”，部分输出标记取消 |
| 提交前的服务/协议错误 | 对本条原消息回复可读错误 |

### 8.2 必要的模型响应边界

拟增加通用事件（名称为设计建议）：

```text
ModelResponseStarted { response_id }
ModelOutput          { response_id, content }  # content 为 delta
ModelResponseEnded   { response_id, disposition }

disposition:
  tool_calls    # 模型输出后还需要执行工具
  final         # 执行器接受为本轮最终回答
  continue      # 无工具，但有补充输入或编排要求继续
  discarded     # 空输出重试等未采用的响应
  failed        # 截断、过滤或流错误
```

`response_id` 在实际模型请求处生成，绑定本次 task，覆盖同一 turn 中的重试和多次模型调用；所有正文 delta 携带该 ID。response ended 由执行器在响应消费和语义判定后发出，不能只依赖 finish_reason：空输出语义重试、pending inputs、todo-mode 编排都可能继续执行。

normal 和 todo mode 使用同一个边界契约。结束事件要在后续模型响应开始前发出；流中断也必须关闭当前响应为 failed。旧事件序列化、反序列化和所有消费者同步更新，不能靠 Lark 特有 hook 猜测工具事件顺序。

### 8.3 实时输出为何使用“每次响应一张卡片”

流式正文先出现时，尚不知道模型稍后是否会产生工具调用。若缓存整段等模型结束才分类，最终回复也会失去模型生成过程中的实时性。

因此每次响应在收到第一段非空正文时：

1. 创建独立的 CardKit 流式卡片，回复本轮原消息，开始逐步更新正文。
2. response ended 为 tool_calls/continue 时，flush 正文、关闭该卡流式模式，将其作为完整的中间消息保留；下一次有正文的响应创建新消息。
3. response ended 为 final 时，flush 正文，但只有服务整轮 `Finished::Succeeded` 后才把卡片标为完成。保存历史或 after hook 失败也必须反映到用户。
4. 整轮失败时关闭当前卡片为“执行失败”，再回复一条带 `ERROR` 标签和具体错误说明的消息；已经发出的中间正文保留。

中间内容也是一条独立消息；允许它生成时逐步更新，不将所有模型响应追加到同一张最终卡片。最终响应会从首段正文开始实时更新，无须等工具执行或整个 round 结束后模拟流式。

若模型后端只返回 completed 响应，发送完整正文并使用卡片的打字机效果；这是显示层流式，不等于模型端真实流式。正常 FAE 模型请求当前设为 `stream: true`。

### 8.4 CardKit 更新流程

通过 SDK 封装以下操作：

| 操作 | 飞书 API |
|---|---|
| 创建卡片实体 | `POST /open-apis/cardkit/v1/cards` |
| 回复原消息，引用 card ID | `POST /open-apis/im/v1/messages/{message_id}/reply` |
| 按全文流式更新正文组件 | `PUT /open-apis/cardkit/v1/cards/{card_id}/elements/{element_id}/content` |
| 关闭流式模式、更新摘要 | `PATCH /open-apis/cardkit/v1/cards/{card_id}/settings` |

使用 SDK 的 Card JSON 2.0 类型及 `CardDocument` 校验，启用 `streaming_mode` 和共享更新，正文组件固定 `element_id = "answer"`。初始提示与正文组件分开，避免把“生成中...”当作正文前缀。本设计不创建实际卡片或提交飞书写入。

CardKit 要求传入**截至当前的完整正文**，由飞书计算增量。网关累积 delta，默认每 300 ms 合并一次更新；无内容变化不调用，结束时强制 flush。只追加稳定正文，Markdown 修正造成前缀变化时可能全量刷新。

每张卡片只有一个 writer，所有内容、settings 和其他变更共享严格递增的 `sequence`。这与服务事件 `seq` 是两个不同序列。每项变更使用独立幂等 UUID；重试同一次变更复用原 UUID/sequence/内容，不允许旧更新晚到覆盖终态。

卡片实体只发送一次，不给多条消息重复引用。卡片 JSON 和富文本有 30 KB 体积限制，按实际 UTF-8 序列化大小预留余量；正文接近容量时在安全字符/Markdown 边界拆分为续篇卡片，按页更新并关闭上一页，避免截断内容。

正常终态流程：正文 flush → 更新摘要/关闭 streaming_mode → 记录投递完成 → 删除 Typing。关闭流式的调用也占用下一 sequence。飞书客户端低于 7.20 对 Card JSON 2.0 的支持有限，需在部署说明中列明。

### 8.5 错误和降级

- Agent 错误：发出 `ERROR：<经脱敏的具体错误>`，附短追踪 ID。避免发送 token、密钥、完整请求体和工具输出；日志保留必要定位信息。
- 生成一部分后失败：保留正文，标明未完成，并发送错误消息。`Completed` 和 `Finished` 不重复触发错误通知。
- CardKit 临时故障：有界重试，合并等待期间的 delta；不拖住服务事件读取。
- 流式模式超时关闭：按官方错误码重新开启一次，再更新；持续失败降级为分段文本回复，明确“流式回复失败，以下为完整结果”。
- 创建/更新卡片不可用：保存最终正文，以文本发送兜底。这是异常降级，不视为通过“最终流式回复”验收。
- 原消息撤回、不支持 reply：若平台仍允许在原 chat 发消息，可回退 create 到同一 chat；不改发到其他聊天或另一个用户。
- 所有发送通道均失败：持久化待投递和错误、在 `fae lark status` 显示告警，稍后有界重试。网络/权限阻断时无法保证用户实际收到，应与 Agent 执行失败分开报告。

## 9. 并发、限流与恢复

### 9.1 会话串行与跨会话并行

完整 worker key 为 `(actual_agent_id, user_id, session_id)`。每个 key 一个有界 FIFO、一个活动 round、一条服务连接。不同 key 可以并发，受网关全局 Agent 并发限制及 server 限制共同约束。

执行期间新消息立即添加 Typing，再进入该 session 队列。排队不改变当前 round 的输入、回复锚点和取消范围。队列按网关可靠接受顺序执行，官方事件时间戳不用于无限等待重排；重复消息不增加队列长度。

队列满时回复“当前会话待处理消息过多，请稍后再试”，删除对应 Typing，不调用 Agent。空闲 worker 在 TTL 后关闭连接并回收；下次使用稳定 session ID 打开，恢复既有历史。

飞书发送需要同时控制应用、chat 和 card 的额度。官方 reply 对同一用户/群组有 5 QPS 限制，单卡操作指南有 10 次/秒限制；CardKit content 文档还列出应用级 50 次/秒、1000 次/分钟。默认 300 ms 只是合并间隔，不代替全局限流，应按这些约束和服务返回的限流提示取更严格预算。

遇到 429 / 频控错误使用退避与抖动，有 Retry-After 时优先遵循。飞书 API 重试由 SDK 或网关一层拥有；若需要网关 outbox 统一重试则关闭 SDK 请求层重复重试，避免放大。

### 9.2 收发记录

建议状态目录：

```text
<FAE_HOME>/lark/
├── runtime.json                  # PID、实例、版本、健康状态，不保存密钥
├── gateway.lock                  # 当前 home 独占进程锁
├── records/<receipt-hash>.json    # 每条输入的可靠接收和投递状态
└── gateway.log                   # 脱敏、轮转日志
```

`receipt-hash = SHA256(["fae-lark-message-v1", app_id, tenant_key, message_id])`。

每条记录保存身份 tuple、session ID、消息正文或恢复所需的输入、状态、reaction ID、external request ID、service instance/stream/round ID、已消费服务 seq、response/card/message IDs、卡片更新序号、待发送正文和终态。采用单 writer 和同目录临时文件原子替换，可靠落盘后才确认状态推进；文件权限与会话历史一致。

消息正文只为入队恢复和待投递所需而存储，完成后按保留策略删除；日志不记录完整正文。活动及未投递记录不参与 TTL 清理，已完成记录建议保留 7 天用于业务去重。该值是本方案默认策略，不是飞书保证的重投窗口。

拟定状态：

```text
Received → Queued → Submitting → Running → Delivering → Delivered
                        └→ AcceptanceUnknown
任意执行阶段 → Failed / Cancelled → Delivering → Delivered
```

Agent outcome 与 delivery state 分开记录：Agent 成功不代表消息已投递，消息发送失败也不应该把已成功 Agent 重跑一遍。

飞书回复 UUID 用持久化的标准 UUID（不超过 reply 的 50 字符限制）；不同 response/分页/错误消息使用不同 UUID。平台回复去重窗口为 1 小时，本地投递台账负责更长时间的防重。超过窗口的接受结果未知不能盲发同一个卡片实体。

### 9.3 断线与重启

- 飞书长连接断开：SDK 重连；已接收任务继续执行，出站 API 按自身可用性处理。
- 网关与 server 断开：按原 instance/stream/seq resume；恢复事件按 seq 去重，再投递到原 response writer。
- 收到 `resume_gap`：不能仅跳过缺失事件继续拼正文。当前 round 标记输出不完整，查询已记录终态或等待终态后发送最终正文兜底；未明确恢复前不重跑。
- server 重启：旧活动任务不可恢复时标为“服务重启，本次执行已中断”，发送错误；队列中未提交的任务可以在服务恢复后开始。
- 网关重启：已落盘未提交的队列恢复；运行中任务先 resume/查询；缺少 round 关联且无法证明未提交时归为 AcceptanceUnknown，不自动重跑。
- 在读取服务事件后，先把正文累积和待投递操作落盘，再推进持久化消费 seq。现有 Client 内存中提前更新 seq 的行为需要配合该提交点扩展，避免崩溃后漏发。
- 不强行承诺无限期恢复：服务重放缓存有限，飞书卡片有效期为 14 天，超出能力边界按明确错误和最终正文降级处理。

一个 app 的长连接是集群投递，多个接收实例不会收到广播副本。首版一个 home 独占网关，同一个 app 不部署多个独立 home 的接收实例；多实例部署需共享接收台账和 session 所有权，另行设计。

## 10. 配置文件

配置格式选择 JSON，与 `server.config` 及现有 Agent 配置习惯一致。用户提到的 appkey 对应飞书 App ID，规范字段为 `app_id`；读取器可接受 `app_key` 别名，两者同时出现时拒绝，密钥字段为 `app_secret`。

示例（全部为占位值）：

```json
{
  "version": 1,
  "app_id": "cli_example",
  "app_secret": "<APP_SECRET>",
  "tenant_key": "<TENANT_KEY>",
  "agent_id": "fae",
  "workspace": "/absolute/path/to/workspace",
  "group": {
    "require_mention": true,
    "reply_in_thread": false
  },
  "execution": {
    "max_concurrent_rounds": 4,
    "session_queue_capacity": 16,
    "session_idle_secs": 1800
  },
  "output": {
    "flush_interval_ms": 300
  },
  "storage": {
    "completed_record_retention_days": 7
  }
}
```

约定：

- 默认位置 `~/.fae/lark.config`；指定 `--fae-home` / 项目现有 `FAE_HOST` 时随 home 变化。
- `app_id/app_secret/tenant_key/agent_id/workspace` 必填。workspace 必须是经展开、规范化后存在的目录；后台启动不能依赖子进程当前目录。
- 首版固定飞书平台地址 `https://open.feishu.cn` 和 WebSocket 模式；不暴露可任意发送应用凭证的 URL 配置。
- 首版 `require_mention` 固定 true，修改为 false 校验失败，直到明确实现群内全消息接收策略。
- Agent、workspace 只由管理员配置；飞书用户正文不能切换 Agent、home 或 workspace。
- 未知字段、非法版本、空密钥、路径或正整数范围错误必须报错，不带着默认值启动。
- 配置不包含 PID、连接状态、access token；运行信息单独保存。
- 文件创建采用 Unix 0600 / 相应 Windows 用户访问权限，写入原子替换；show/status 不输出 app secret 或 token。
- 没有 `enabled=true` 的自启动开关，配置文件存在也不会被普通 fae/TUI/server 启动路径激活。
- 首版编辑配置后 `fae lark stop` 再 `fae lark start` 生效；不做热更新。停止时可用运行信息定位进程，不依赖新配置仍然有效。

## 11. CLI 与网关生命周期

拟新增：

| 命令 | 行为 |
|---|---|
| `fae lark init` | 生成配置模板，不启动进程；已有文件不覆盖，显式 `--force` 才覆盖 |
| `fae lark check` | 校验配置、Agent、workspace 和隔离策略，不启动进程 |
| `fae lark check --online` | 通过 SDK 检查认证、机器人信息等在线能力，不发测试消息 |
| `fae lark show` | 展示脱敏配置和文件路径 |
| `fae lark start` | 显式启动后台网关，等待 ready，必要时自动启动 Agent server |
| `fae lark start --foreground` | 当前终端运行网关，便于部署与日志查看 |
| `fae lark status` | 查看 PID、连接健康、活动/排队 round、未投递数及最近错误，不自动启动 |
| `fae lark stop` | 停止接收、取消本网关活动 round 并通知用户、保存待投递状态、退出 |

全局 `--fae-home` 继续有效。Lark workspace 以配置为准；执行 lark 命令显式传入冲突的全局 `--workspace` 时应报错，不能被根参数默认 `"."` 静默覆盖。命令默认 agent 注入逻辑须将 `lark` 加入根子命令名单。

`start` 流程：

1. 校验配置并取得当前 home 的网关独占锁。
2. 使用现有 server discovery/ensure 能力，必要时启动 server。
3. 验证协议版本、网关身份绑定和事件边界能力，取得本地 gateway token。
4. 创建 SDK client，验证 App 凭证、机器人身份与租户关联，恢复本地台账。
5. 建立长连接；本机服务可用且 SDK on_ready 后发布 runtime ready 信息。
6. 父启动命令校验实例握手再返回成功；部分启动失败回收网关资源并报错，已经启动的公共 server 继续由 server 命令管理。

同一 home 的重复 start 返回已运行实例信息。status 必须验证 PID 对应实例和本地控制握手，不能只用 PID 存在判断。建议复用 server lifecycle 的锁、实例 ID、健康握手思路，网关单独提供本机管理通道且只绑定 loopback。

`stop` 只影响本网关拥有的 round；不能取消 TUI 或其他用户/会话执行。停止通知与错误投递失败时保存 outbox。`server stop` 不自动把网关停止：网关报告 degraded，旧 round 报错，暂停新提交；运行中的网关可以按退避恢复它依赖的 server。执行 `fae lark stop` 不停止公共 server。

**默认启动矩阵：**

| 操作 | Agent server | Lark 网关 |
|---|---|---|
| `fae` / `fae agent` / `fae workflow` | 按现有规则必要时启动 | 不启动 |
| `fae server start` | 启动 | 不启动 |
| `fae lark init/check/show/status` | 不自动启动 | 不启动 |
| `fae lark start` | 必要时启动 | 启动 |
| 配置文件已经存在 | 无额外动作 | 不启动 |

## 12. 实施顺序与验收

首版实现按以下依赖顺序推进：

1. 增加服务显式身份绑定、完整 key/resume 校验和受限网关认证。
2. 增加模型 response ID/边界事件，覆盖 normal、todo、空输出重试、流失败和子 Agent。
3. 补齐 Lark context 的 session 工具状态分区，特别是 todo，或在能力就绪前启动拒绝。
4. 实现配置、CLI、SDK 长连接、可靠入队和 Typing。
5. 实现 session worker、服务调用、卡片状态机、错误回复和限流。
6. 实现收发台账、接受结果查询、断线恢复和进程生命周期。
7. 更新 `app/fae/README.md`，提供权限设置及单聊/群聊验收步骤。

核心验收：

- 单聊收到文本，原消息立即得到 Typing，最终回答真实流式更新，结束后表情删除。
- 模型先正文再工具调用、连续多次工具调用时，每段模型正文成为独立消息，工具事件和 reasoning 均不出现。
- 只有工具调用时不发空消息；最后正文不会同时从 delta、Completed 和 Finished 发送三次。
- 模型流截断、工具失败、历史保存/after hook 失败时，都显示错误，不能先标成功后又报错。
- 同一用户单聊/G1/G2 历史分开；同群不同用户分开；agent ctx、子 agent ctx 和存储路径都使用飞书 user ID。
- 同时打开相同 target/session 但不同用户时不会复用 actor；跨用户 stream resume 被拒绝。
- 缺少 user_id 权限明确提示，不回退 master/open ID；非配置租户和机器人消息不执行。
- 重复 message_id、不同 event_id 的重复投递、断线后不确定 Ack，不造成自动重复工具执行。
- 同 session 顺序执行，跨 session 并行；todo 状态和取消范围不会互相影响。
- 多字节长文本、代码块、卡片分页、频控、流式超时、CardKit 失败都能保留可读最终结果。
- 网关/server 重启、resume gap、崩溃在发送前后时，行为符合恢复边界，不伪称投递成功。
- 普通 fae、TUI、server start 在存在 lark.config 时仍不会启动 Lark。
- 错误配置、重复 start、PID 复用、stop 后重启和脱敏输出经过验证。

实现验证使用 Rust 格式检查、`cargo check` 和针对身份/状态机/恢复的必要测试；真实飞书与真实模型验收单独执行。

## 13. 核对来源与能力边界

核对日期：2026-11-08。平台契约以飞书官方文档为准；crate 能力以固定版本文档为准。以下来源验证接口与 SDK 能力，方案中的 session 算法、目录、CLI、恢复策略和默认参数是本项目拟定决策。

- [larksuite-oapi-sdk-rs 0.3.13](https://docs.rs/crate/larksuite-oapi-sdk-rs/0.3.13)：SDK 身份、features、最低 Rust 版本、IM 与 CardKit 能力。
- [SDK 构建飞书机器人教程](https://docs.rs/crate/larksuite-oapi-sdk-rs/0.3.13/source/docs/tutorial-build-a-feishu-bot.md)：typed 事件、快速入队、长连接、消息 UUID。
- [SDK Cards 指南](https://docs.rs/crate/larksuite-oapi-sdk-rs/0.3.13/source/docs/cards.md)：版本化 CardDocument、CardKit entity、序号更新。
- [飞书接收消息事件](https://open.feishu.cn/document/server-docs/im-v1/message/events/receive)：用户字段权限、租户、chat/thread/message ID、message_id 去重。
- [飞书长连接处理事件](https://open.feishu.cn/document/server-side-sdk/golang-sdk-guide/handle-events)：企业自建应用限制、3 秒处理窗口、集群而非广播投递。
- [飞书表情说明](https://open.feishu.cn/document/uAjLw4CM/ukTMukTMukTM/reference/im-v1/message-reaction/emojis-introduce)：`Typing` 表情枚举。
- [飞书回复消息](https://open.feishu.cn/document/uAjLw4CM/ukTMukTMukTM/reference/im-v1/message/reply)：回复目标、话题规则、容量、限流、UUID 长度与去重窗口。
- [飞书流式卡片指南](https://open.feishu.cn/document/cardkit-v1/streaming-updates-openapi-overview)：Card JSON 2.0、创建实体后发送、客户端版本和单卡限频。
- [飞书流式更新文本](https://open.feishu.cn/document/cardkit-v1/card-element/content)：完整文本、严格递增 sequence、容量与流式超时错误。

已完成 SDK 编译集成与本地模拟验证；尚未执行真实飞书写入、权限开通验证和真实模型端到端测试。首版关键前提是企业自建应用、固定租户、可获得飞书 user ID；异常文本降级不能替代正常流式能力验收。

## 14. 首版实现记录

实现入口为 `app/fae/src/lark/`，命令包含 `init/check/show/start/status/stop`。
服务使用协议 v2 与独立的 `lark.token`；升级后应重启旧服务。
模型响应边界在 single-agent 通用执行器中产生，正文携带 response ID，
兼容读取没有 response ID 的历史事件；TUI 忽略新增边界事件。

SDK 0.3.13 的 `max_retries` 实际是**总尝试次数**（循环为 `0..max_retries`）。
因此配置为 1 才表示执行首次请求且禁用内部重复重试；设为 0 会完全不发请求。
网关的出站台账拥有重试，卡片 mutation 在请求前保存 sequence/UUID/正文。
本地模拟测试检查首次请求、相同 mutation 重试、整轮结束后关闭和单次卡片引用。

当前执行限制：

- Todo 尚未添加通用 session 分区策略。启动和服务绑定检查拒绝配置了 `todo`
  的 Agent、子 Agent，或显式包含 Todo 的 workflow。应先移除这些路由。
- 多模态、跨租户、多网关共享所有权不在首版范围内。
- 台账完成记录按配置保留；服务输入接受记录暂时保守保留，不自动删除。
- 卡片更新失败有退避和文本降级；已经尝试发布但接受结果未知的回复不会
  盲目换 UUID 重发，超过飞书去重窗口保留未投递告警供管理员处理。
- SDK 事件头不出现在 typed message payload 中；应用身份来自 SDK 认证的
  长连接，发送者租户仍逐事件匹配固定 `tenant_key`。
- 状态中的服务健康通过本机服务握手计算；停止网关不停止公共服务。

真实部署应按第 12 节验收，尤其核对卡片超时的实际平台错误和频控响应。

本地验证结果：`cargo check --workspace` 通过；`fae` 库测试 58 项、
`fae-agent` 库测试 90 项、服务集成测试 14 项通过，最终重新验证了飞书身份与输入去重用例。
所有修改的 Rust 文件通过 rustfmt 与 `git diff --check`。
`cargo fmt --all -- --check` 仍报告未修改文件中的既有格式差异，
例如 `app/fae/src/app/paths.rs`；未为此扩大本次功能变更范围。
