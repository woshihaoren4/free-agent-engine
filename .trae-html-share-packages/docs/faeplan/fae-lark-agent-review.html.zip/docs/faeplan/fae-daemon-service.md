# FAE 服务常驻与 TUI 分离方案

状态：已实施；macOS 全目标编译及 228 项自动化测试通过，真实模型、终端人工验收和 Windows 平台验证待执行。  
日期：2026-11-03。  
范围：`app/fae`，以及支持远程会话取消所必需的少量 `fae-agent` 公共接口调整。

## 1. 目标与设计结论

将 `app/fae` 拆为前台客户端和后台常驻服务。继续发布一个 `fae` 可执行文件，通过不同命令启动不同角色：

- `fae`、`fae agent`：检查服务、必要时启动后台服务，再连接对话。
- `fae workflow`：同样通过后台服务执行，保留交互和非交互输出方式。
- `fae server start [--address <address>] [--port <port>]`：显式启动后台服务，地址默认 `127.0.0.1`，端口默认 `6666`，避免普通用户监听特权端口时失败。
- `fae server stop`：停止当前 home 对应的服务，不触发自动启动。
- `fae server status`：查看服务状态，不触发自动启动。

默认检查 `~/.fae/server.config`，该 JSON 文件统一保存服务 PID、地址、端口和实例信息，客户端据此连接服务。配置了其他 FAE home 时，使用对应 home 下的 `server.config`，确保不同 home 的配置、进程和会话互相隔离。不再使用独立的 `pid` 或 `server.json` 文件。

端口冲突时必须报错并启动失败，不自动切换端口，也不让系统随机分配端口。自动拉起尚未运行的服务时，同样使用默认 `127.0.0.1:6666`；已有有效服务则使用 `server.config` 中记录的地址和端口。

客户端与服务通过本机 WebSocket 交换 JSON。每个 session 对话建立一个独立双向连接，同一连接可以承载该 session 的多个回合；不在一条连接中复用多个 session。服务在客户端退出后继续常驻，运行中的任务默认继续执行。

按以下目录组织：

- `src/tui/`：终端渲染、键盘输入、文件选择和显示状态。
- `src/server/`：WebSocket 服务、引擎组装、会话管理、后台生命周期。
- `src/app/`：CLI、服务发现与拉起、客户端连接、命令调度。
- `src/protocol/`：双方共享的消息定义，不依赖 TUI 或服务实现。

实现按第 11 节推进，已建立模块边界并接通后台服务。

## 2. 现有代码及迁移依据

| 现有位置 | 当前职责 | 目标位置 |
| --- | --- | --- |
| `app/fae/src/main.rs` | 模块声明、Tokio 入口、错误退出 | 保留薄入口 |
| `app/fae/src/args.rs` | CLI 及默认插入 `agent` 子命令 | `src/app/args.rs` |
| `app/fae/src/app.rs::run_agent` | 加载配置、创建 Engine、启动回合、驱动 UI | 拆到 `app/agent.rs` 与 `server/session.rs` |
| `app/fae/src/app.rs::run_workflow` | 工作流输入解析、执行和显示 | 拆到 `app/workflow.rs` 与 `server/session.rs` |
| `app/fae/src/app.rs::build_engine` | 注册 runtime、tools、plan builders | `src/server/engine.rs` |
| `app/fae/src/app.rs::clean_session_data` | 删除历史和 agent/user 级 todo | `src/server/session.rs` |
| `app/fae/src/app.rs::PythonActionRuntime` | 工作流 Python action 执行 | `src/server/runtime/python.rs` |
| `app/fae/src/tui.rs` | 渲染、输入、事件处理、日志捕获 | 拆入 `src/tui/` |
| `app/fae/src/file_browser.rs` | 本地文件选择 | `src/tui/file_browser.rs` |
| `app/fae/src/workspace.rs` | 路径解析及 WorkspaceHook | 路径解析移入 `app/paths.rs`，hook 移入 `server/workspace.rs` |
| `app/fae/src/init.rs` | 初始化配置 | `src/server/init.rs`，经控制连接调用 |

当前 TUI 直接接收 `Session` 和可选 `Ctx`。首次回合由 `engine.launch()` 返回 `Ctx`，后续回合由 `session.call(NewChat(...))` 内部创建新 Context。前台持有首次 `Ctx` 不能代表所有后续回合，取消能力必须改成服务对“当前回合”的操作。

现有可复用类型位于 `crates/fae-agent/src/session/mod.rs`：

- `SessionInputData`、`SessionInput` 已有 serde 支持，包含文本、图片、文件和二进制输入字段。
- `SessionOutput` 已有 serde 支持，包含父计划、计划、节点、Agent 名称及事件内容。
- `SessionMessage` 可用于历史查询。
- `SessionOutput::is_terminal()` 已排除嵌套 Agent 的结束事件，应继续使用。

`SingleAgentSource` 也已支持序列化。内部 `Event`、`TaskRequest`、`Ctx` 含运行态对象，不作为网络消息。协议不修改 `SessionOutput` 的字段拼写，包括现有的 `parament_plan_id`。

## 3. 进程和职责边界

```mermaid
flowchart LR
    A["fae 客户端 A / TUI"] -->|session A 独立 WebSocket| S["fae 后台服务"]
    B["fae 客户端 B / TUI"] -->|session B 独立 WebSocket| S
    C["非交互 CLI"] -->|独立 WebSocket| S
    S --> M["SessionRegistry"]
    M --> EA["session A: Engine + CommonSession"]
    M --> EB["session B: Engine + CommonSession"]
    EA --> R["fae-agent / fae-engine runtimes"]
    EB --> R
    R --> D["FAE home: 配置 / 历史 / todo / memory"]
```

前台负责解析参数、把相对路径解析为绝对路径、选择附件、解析 `/todo` 等界面命令，以及显示事件。前台不创建 Engine，不直接读取或修改 session/todo/memory 状态。

服务负责加载配置、组装 Engine、注入工作区上下文、创建和管理 Context、执行工具、持久化历史、清理数据和输出结果。工作流中的子 Agent 事件继续经父 session 转发，由同一连接发送，保留现有名称前缀和子 Agent 输出缓冲行为。

一期为每个打开的逻辑 session 延迟创建独立 Engine，复用现有 `build_engine`。这样可让绑定固定 workspace 的 `WorkspaceHookBuilder` 留在会话内，避免共享 Engine 的 hook 混入其他工作区。多会话共享 runtime 或 Engine 池作为后续优化，不在拆分时引入。

后台常驻不等于所有 Engine 永久保留。已完成且断开的 session 超时后释放 Engine；重新进入时从现有历史恢复。

## 4. 服务发现与自动启动

### 4.1 运行文件

记规范化后的 FAE home 为 `<home>`。一期沿用现有 `--fae-home`、`FAE_HOST` 和 `default_fae_host()` 的解析规则，不额外改变环境变量优先级。默认 `<home>` 为 `~/.fae`。

| 文件 | 内容和用途 |
| --- | --- |
| `<home>/server.config` | JSON：PID、地址、端口、服务实例、协议版本、启动时间、可执行文件路径；客户端连接依据 |
| `<home>/server.token` | 本地连接随机凭据，每次服务启动重新生成 |
| `<home>/start.lock` | 串行化客户端的检查和拉起操作 |
| `<home>/server.lock` | 服务整个生命周期持有的 OS 文件锁，保证唯一实例 |
| `<home>/log/server.log` | 后台 stdout/stderr 和运行日志，按大小轮转 |

`server.config` 示例：

```json
{
  "instance_id": "6b9c-service-instance",
  "pid": 32145,
  "address": "127.0.0.1",
  "port": 6666,
  "protocol_version": 1,
  "app_version": "0.1.0",
  "started_at": "2026-11-03T08:00:00Z",
  "executable": "/usr/local/bin/fae"
}
```

`address` 保存实际监听 IP，`port` 保存实际监听端口，`pid` 保存服务自身进程号。客户端读取这三个字段检查进程并构造 `ws://<address>:<port>/v1/control` 或 `/v1/session`，不另存可能与地址、端口不一致的 endpoint 字段。IPv6 地址构造 URL 时加方括号。

显式命令示例：

```bash
fae server start
fae server start --address 127.0.0.1 --port 2666
fae server start --address 0.0.0.0 --port 2666
fae server status
fae server stop
```

`--address` 接受合法 IPv4/IPv6 监听地址；`--port` 范围为 `1..=65535`，拒绝 `0`。地址为 `0.0.0.0` 或 `::` 时，配置仍保存实际绑定地址，本机客户端分别映射到 `127.0.0.1` 或 `[::1]` 连接；具体 IP 则直接使用。远程客户端管理不纳入一期。

`server start` 成功返回前必须完成后台就绪握手，并打印 PID、地址、端口和配置路径。若同一 home 的服务已经运行且监听参数相同，返回“已运行”；若参数不同，报错并要求先 stop 后 start，不在线修改监听地址。

### 4.2 启动流程

1. 客户端规范化 home，创建运行目录，获得 `start.lock`，在锁内重新检查状态。
2. 读取 `server.config`，校验 JSON、正整数 PID、合法 IP 地址及 `1..=65535` 端口；缺失、空值、非法值都视为待恢复状态。
3. 检查 PID 是否存活。Unix 使用 `kill(pid, 0)`，`EPERM` 表示存在但无权限；Windows 使用进程句柄和状态查询。
4. 使用配置中的地址、端口及独立凭据，建立有超时的 WebSocket 控制握手，校验 PID、`instance_id`、home 和协议版本。PID 存在本身不能证明它就是 FAE，也不能证明服务就绪。
5. 若握手成功，直接复用，客户端不能硬编码连接默认端口。
6. 若未发现有效服务，尝试获取 `server.lock`。只有确认没有实例持锁后才允许拉起；检查用的锁必须在子进程获取前释放。
7. 用 `std::env::current_exe()` 启动 `fae --fae-home <absolute-home> server start --address <address> --port <port> --foreground`，不依赖 PATH，不通过 shell 拼接命令。`--foreground` 是内部隐藏参数，让子进程直接进入服务循环，避免再次拉起自身；该子进程不竞争父进程正在持有的 `start.lock`，只获取 `server.lock`。用户显式 start 和自动拉起共用启动实现。
8. 服务自行获得并持续持有 `server.lock`，绑定指定地址和端口，初始化控制处理和会话管理器，再发布 token 和 `server.config`；配置中的 PID 由服务写入自己的 `std::process::id()`。绑定失败立即以非零退出码退出，不发布新的有效配置。
9. 客户端等待同一子进程发布信息并完成握手，默认总超时 10 秒，使用有界退避；成功后释放 `start.lock` 并进入业务连接。

`server.lock` 是最终唯一性依据。两个后台服务子进程也必须竞争同一锁，失败的一方退出，不写运行文件。锁文件不能删除重建来“解锁”，避免不同 inode 上各持一把锁。

发布文件采用同目录临时文件加原子替换。先发布凭据，再一次性发布包含 PID、地址和端口的 `server.config`；客户端始终以握手作为就绪判断。监听失败或端口冲突不能覆盖其他存活实例的配置；失效旧配置可以清理，但不能留下本次失败进程的配置。

### 4.3 异常处理

| 情况 | 处理 |
| --- | --- |
| PID 不存在或对应进程已退出 | 获取启动锁，确认服务锁空闲，清理失效发现信息并拉起 |
| PID 被其他进程复用 | 握手校验不通过，不向该 PID 发信号；服务锁空闲时恢复 |
| server.config 缺失、服务锁占用 | 报告服务发现信息缺失；不猜测地址和端口，不启动第二实例 |
| PID 活着、服务锁占用，但端点一直不可用 | 有界等待后报告启动失败或服务无响应；不启动第二实例 |
| server.config 损坏但服务锁占用 | 报告发现信息损坏，保留原服务；不猜测端口、不误杀 |
| 指定端口被其他服务占用 | 返回 `address_in_use` 和冲突的地址、端口，启动失败，不自动换端口 |
| 地址不可绑定或端口绑定权限不足 | 返回具体绑定错误，启动失败；不更换地址、端口 |
| 协议版本不兼容 | 明确报告版本错误，不自动停止有活动任务的服务 |
| 子进程提前退出 | 收集退出状态，显示日志路径；结束等待 |
| 权限不足 | 报告具体文件或进程错误，不把它当作进程不存在 |

“每次运行 fae 检查服务”覆盖所有业务入口，包括 `init`、`uninstall`、Agent 和 workflow。`--help`、`--version` 不启动服务；`server start/status/stop` 直接进入管理逻辑，避免递归拉起。默认子命令插入逻辑须识别 `server`，不能把它解析为 Agent 提示词。`init` 通过控制连接执行；`uninstall` 先让服务正常停止，再删除当前可执行文件。

### 4.4 脱离终端与停止

Unix 子进程启动时使用 `setsid`，stdin 接空设备，stdout/stderr 接日志，不继承前台终端。Windows 使用对应的 detached/new process group 标志，并重定向标准句柄。丢弃子进程句柄不得触发 kill-on-drop。服务不依赖前台 Tokio 任务存活。

一期不安装 launchd/systemd，也不保证操作系统重启后自动启动。下次执行业务命令时自动恢复。

`fae server stop` 读取 `server.config` 并经对应控制连接提出 shutdown：停止接受新请求，取消所有活动回合并等待清理，调用各 Engine 的 `exit()`，关闭连接，删除属于本实例的 `server.config` 和 token，最后释放服务锁。stop 等待进程退出和锁释放后才返回成功，不能将请求已发送当作停止完成。服务未运行时返回“未运行”，不自动启动；只有确认服务锁空闲后才清理失效配置。

默认清理期限 10 秒；无法完成时保留可诊断状态并报告失败，不凭裸 PID 强杀。服务同时处理 SIGTERM，Unix 直接前台运行时也处理 SIGINT。正常停止后，下次隐式拉起使用默认地址和端口；自定义监听参数需要再次显式 start。

## 5. WebSocket 通道与协议

### 5.1 通道约束

- `/v1/control`：短连接，负责健康握手、初始化、状态和停止。
- `/v1/session`：每条连接只绑定一个逻辑 session；首条业务消息必须是 `open`。
- 控制连接不传输对话事件，对话连接不切换绑定身份。
- WebSocket 文本帧传 JSON，使用原生 Ping/Pong 保活，不在消息层重复定义心跳。
- HTTP Upgrade 使用 `Authorization: Bearer <token>`；握手失败即拒绝升级。默认监听 loopback，显式 start 时使用用户指定地址；所有地址均保留认证并拒绝浏览器 Origin 请求。
- token 文件 Unix 权限为 `0600`，新建运行目录为 `0700`；已有 home 不擅自改权限，凭据创建时必须保证受限访问。Windows 使用当前用户 ACL。

同机共享文件系统，附件仍使用现有 `SessionInputData` 字段。客户端把本地路径解析为绝对路径，服务检查可读性，不按后台 cwd 解析相对路径。一期不增加文件上传或远程主机连接能力。

### 5.2 消息封装

协议新增传输和控制信息，业务输入、输出直接嵌入已有类型：

```rust
// 方案草图，后续放入 src/protocol/，不是当前已存在的接口。
#[derive(Serialize, Deserialize)]
struct ClientEnvelope {
    version: u16,
    request_id: String,
    #[serde(flatten)]
    body: ClientMessage,
}

#[derive(Serialize, Deserialize)]
#[serde(tag = "type", content = "data", rename_all = "snake_case")]
enum ClientMessage {
    Open(OpenSession),
    Input {
        input: SessionInput,
        mode: Option<String>,
    },
    Cancel { round_id: String },
    History { limit: usize, offset: usize },
    Clean,
    Status,
    Close { cancel_active: bool },
}

#[derive(Serialize, Deserialize)]
struct ServerEnvelope {
    version: u16,
    instance_id: String,
    stream_id: Option<String>,
    request_id: Option<String>,
    #[serde(flatten)]
    body: ServerMessage,
}

#[derive(Serialize, Deserialize)]
#[serde(tag = "type", content = "data", rename_all = "snake_case")]
enum ServerMessage {
    Opened(SessionInfo),
    Ack { round_id: Option<String> },
    Event {
        seq: u64,
        round_id: String,
        output: SessionOutput,
    },
    Finished {
        seq: u64,
        round_id: String,
        outcome: RoundOutcome,
    },
    History { messages: Vec<SessionMessage> },
    Status(SessionStatus),
    Cleaned,
    Closed,
    Error(ProtocolError),
}
```

`RoundOutcome` 为类型化的 `Succeeded { result: Value }`、`Failed { message: String }`、`Cancelled { reason: String }`。不直接序列化 `ContextState` 或 `ContextOutput`。

`OpenSession` 包含：

| 字段 | 含义 |
| --- | --- |
| `target` | `Agent { source: SingleAgentSource }` 或 `Workflow { workflow_id, input: Value }` |
| `session_id` | Agent 可省略，采用配置默认值；workflow 可省略并生成执行 session ID |
| `workspace` | 客户端规范化后的绝对工作区路径 |
| `resume` | 可选 `{ stream_id, after_seq }`，用于同服务实例内重连 |

`SessionInfo` 返回有效的 agent/workflow ID、名称、user ID、model、session ID、workspace、运行状态、最新序号，以及重连是否成功。`stream_id` 是运行期流的随机 ID；与用于持久化历史的 `session_id` 分开，服务重启后不复用。

服务从配置解析用户身份，默认仍是 `master`，并通过 Context scope 传给委派链。一期不让客户端在单条消息中任意改写 user ID。显式配置文件、提示词文件路径也由客户端规范化，服务再校验。

控制协议单独定义 `Hello`、`Initialize(InitArgsDto)`、`Status`、`Shutdown` 和对应响应，沿用 envelope；`Hello` 返回服务 PID、实例 ID、home、应用和协议版本。CLI 的 clap 类型不直接成为协议类型。

### 5.3 命令映射

| 前台操作 | 协议及服务行为 |
| --- | --- |
| 首次发送提示词 | `open` 成功后发送 `input.new_chat`，服务首次 `engine.launch()` |
| 下一回合 | 同一连接发送 `input.new_chat`，服务设置 mode 后调用 `session.call()` |
| `/todo <message>` | 客户端剥离命令，发送 `NewChat` 和 `mode: "todo"` |
| 普通下一回合 | 显式发送 `mode: null`，恢复普通模式 |
| `/steer <message>` | 发送 `Supplement`，仅活动回合接受，mode 必须为空 |
| Ctrl+C | 发送当前 `round_id` 的 `cancel`，等待取消结果，不停止整个服务 |
| `/session new`、`/session id=...` | 关闭当前连接，再为目标 session 建立新连接 |
| `/session clean`、`/clean` | `clean`，由服务删除历史和 agent/user 级 todo，释放旧 session binding |
| `/clear` | 仅清空本地显示，不发网络消息 |
| `/status` | 查询服务侧 session 状态及有效配置 |
| `/exit`、`/quit` | `close { cancel_active: false }`，客户端退出 |
| 非交互 Agent | 独立连接发送一轮，流式打印，收到 `finished` 后返回退出码 |
| 非交互 workflow | `open` 后自动执行一次，只打印 `finished` 的最终 JSON |

Workflow 一期支持事件、状态、取消和最终结果，不接受 Agent 的 `NewChat`、`Supplement`、`mode` 或历史清理命令；收到这些消息返回 `unsupported_operation`。工作流输入 `@path` 的 JSON 文件仍由前台读取和解析后发送。

### 5.4 消息实例

新回合直接复用 `SessionInput` 的现有外部标签序列化格式：

```json
{
  "version": 1,
  "request_id": "req-2",
  "type": "input",
  "data": {
    "input": {
      "new_chat": {
        "text": "实现登录功能",
        "images": null,
        "files": null,
        "data": null
      }
    },
    "mode": "todo"
  }
}
```

服务输出：

```json
{
  "version": 1,
  "instance_id": "6b9c-service-instance",
  "stream_id": "stream-42",
  "request_id": null,
  "type": "event",
  "data": {
    "seq": 8,
    "round_id": "round-1",
    "output": {
      "parament_plan_id": null,
      "plan_id": "plan-123",
      "node_id": null,
      "agent_name": "fae",
      "runtime_id": "model",
      "input_type": "model_output",
      "output": { "content": "开始实现。" }
    }
  }
}
```

`request_id` 关联请求响应，`round_id` 标识顶层回合，`seq` 为同一 stream 内单调递增的事件序号，子 Agent 事件同样占用序号。`ack` 只表示请求已接受，不代表执行成功。

## 6. 会话管理、回合与取消

### 6.1 会话实体

服务维护 `SessionRegistry`，每个实体由串行 actor 管理：

```text
SessionEntry
├── key: kind + effective agent/workflow ID + user ID + session ID
├── stream_id / workspace / source / effective config
├── Engine（延迟创建）
├── CommonSession
├── active round / current Context
├── 唯一事件读取任务
├── connection lease
├── 有界事件重放缓存
└── request_id 去重缓存 / 断开时间
```

同一持久化 Agent key 只能有一个运行期实体，避免两个 Engine 并发写同一 JSONL。workspace 和 source 是绑定属性：另一个客户端尝试用同一 key、不同 workspace/source 打开时返回冲突，不能靠把 workspace 加进 key 来绕过写入互斥。

已连接 session 再被打开时返回 `session_in_use`。断线后释放连接 lease，允许重连。不同 session 可以并发，registry 的全局锁不跨 await 执行 Engine、文件或网络操作。

actor 串行接受状态变更；socket 读取、事件采集和 socket 写入由独立任务完成，长时间的模型执行不能阻塞 cancel/status。首个 `open` 只绑定 Agent session，首次 `input` 才创建执行；workflow 在 `opened` 发出后启动。

### 6.2 回合状态和结束语义

```mermaid
stateDiagram-v2
    [*] --> Idle: open
    Idle --> Running: NewChat / workflow launch
    Running --> Running: Supplement
    Running --> Cancelling: Cancel
    Running --> Idle: Finished succeeded / failed
    Cancelling --> Idle: Finished cancelled
    Idle --> Closed: close 后释放 / 超时回收
```

同一 session 同时只运行一个顶层回合。运行中再发送 `NewChat` 返回 `session_busy`；不隐式利用现有 `NewChat` 的替换取消行为，也不排入不可见队列。需要替换时，先取消并等 `finished`，再发新回合。

事件读取任务是 `CommonSession::answer()` 的唯一消费者。所有输出先进入服务的顺序流和缓存，再交给 WebSocket；不能让多个连接分别读取克隆 session，造成事件被抢走。

`SessionOutput::is_terminal()` 用于识别顶层输出结束，但完整回合结束还须等待当前 Context 的最终状态和对应收尾。服务按顺序先发送已产生的输出，再发送一次 `finished`。客户端看到 `completed` 事件可以结束文本动画，仍须等待 `finished` 才允许下一回合和确定退出码。

取消或启动失败可能没有常规顶层输出事件，服务必须同时观察 Context 终态，不能只等 `answer()`。最终状态只归并一次，已成功的回合收到晚到的 cancel 不得改为 cancelled。终态时排空已入队输出后发送 `finished`，忽略归属于旧 round 的迟到消息。

### 6.3 当前回合取消接口

建议为 `CommonSession` 增加小型公共接口，例如：

```rust
pub async fn cancel_active(&self, reason: &str) -> anyhow::Result<()>;
```

接口在 `fae-agent` 内部解析当前 completion 绑定的 Context，再调用现有 `set_state(ContextState::cancelled(...))`；不要把 `Ctx` 发给客户端。若实现需要暴露当前状态，增加只读 accessor 或状态视图，保持 Context 的具体实现封装。

服务的 `cancel { round_id }` 先确认当前回合 ID，再调用接口；workflow 使用对应 launch Context。验证必须覆盖第二回合以及委派子 Agent，确保取消沿当前 Context 链传播。

服务收到取消请求后返回 ack，完成后发送 `Finished::Cancelled`。若执行已结束，返回明确的 `round_not_active`，客户端读取既有 finished 结果。TUI 按现有运行态 Ctrl+C 的退出意图，等待当前回合取消后退出该客户端；空闲时保持原有退出和终端恢复行为。

## 7. 断线、重连与资源约束

关闭 TUI、网络断开或 Ping 超时只解绑连接，默认不取消后台活动任务。需要取消时使用明确的 cancel 或 `close { cancel_active: true }`。

服务继续采集输出。每个 session 保留按序号排列的内存重放缓存，默认上限 4096 条或 16 MiB，先达到者触发淘汰。运行中允许持续执行，完成后未连接的实体默认保留 30 分钟，随后 `engine.exit()` 并释放。

重连流程：

1. 再次服务握手，确认 `instance_id`。
2. 建立新的 session 专用连接，`open.resume` 携带旧 `stream_id` 和客户端最后应用的 `seq`。
3. 服务在 actor 内原子登记新连接和重放起点，先返回 opened，再发送遗漏事件，再接续实时流，避免重放与实时事件乱序。
4. 客户端以 `(instance_id, stream_id, seq)` 去重，不重复渲染已经应用的输出。

超出缓存范围时返回 `resume_gap`，附当前状态及可用序号范围。客户端明确显示输出不完整，可查询已持久化历史，再从当前序号继续；历史只有会话消息，不冒充完整工具事件重放。服务重启或实体已回收时返回 `resume_expired`，不恢复原运行任务；Agent 可重新打开历史 session，workflow 不自动重跑。

自动重连只重发 open/status/history 等读取操作，不自动重发 input、cancel、clean 或 workflow 执行请求。服务在存活 stream 内缓存最近 256 个请求 ID 和响应，相同 ID、相同内容返回已缓存响应，相同 ID、不同内容返回 `request_id_conflict`。缓存淘汰或实例重启后不承诺 exactly-once；发送成功但未收到 ack 的写操作显示“接受状态未知”，交由状态查询确认，不能静默重复执行。

默认约束：

| 项目 | 初始值 / 行为 |
| --- | --- |
| WebSocket 单条 JSON 上限 | 8 MiB，超出返回错误或关闭连接 |
| 每连接发送队列 | 256 条且累计不超过 8 MiB |
| 心跳 | 15 秒 Ping，45 秒无响应断开 |
| 已绑定 session 数 | 最多 32 个，包含断开后保留的实体 |
| 顶层活动回合数 | 最多 8 个，超限拒绝新执行；不限制现有回合的取消和状态读取 |
| 历史查询 | 单页最多 100 条，消息超过帧上限时返回明确错误 |

慢客户端的队列满时断开其连接，继续后台采集并缓存，不让网络反压卡住执行。现有 SessionOutputChannel 使用无界队列，增加有界网络队列并不自动解决源头内存问题；采集任务必须持续读取，在限制活动回合数的基础上观察内存，后续才考虑核心事件通道背压调整。

## 8. 工作区、持久化与配置

服务不能以启动时 cwd 作为所有 session 的工作区。每个 open 都传绝对 workspace，服务校验目录，再为该会话注册 `WorkspaceHookBuilder`。继续读取 `.fae/workspace.md`、`rules.md`、`agents.md`、`project.md`，保持缺失文件可选和英文兜底说明。

WorkspaceHook 注入提示词与工具 cwd 是两个独立问题。常驻服务不使用全局 `set_current_dir()`；命令类工具明确传 cwd，后续若需默认 cwd，应从 Context 中的会话工作区读取并设置单个子进程目录，不能修改进程级 cwd。实现前核对现有工具路径行为，确保 `apply_patch` 等仍使用显式目标目录。

继续使用现有分区：

```text
<home>/session/<agent_id>/<user_id>/<session_id>.jsonl
<home>/session/<agent_id>/<user_id>/todo.json
<home>/memory/<user_id>.jsonl
```

历史、todo 和 memory 的用户身份从 Context 链传播。网络协议不引入另一套身份状态。

`clean` 不是只清理一个 session 的所有私有数据：todo 实际按 agent/user 共享。服务先检查该 agent/user 是否存在活动回合；有则返回 `cleanup_busy`，避免清理另一 session 正在使用的 todo。检查、禁止新的相关回合进入、取得现有 `TodoTool::lock_for_cleanup()`、删除历史和 todo、释放旧 binding 必须作为同一受控操作完成。沿用路径段校验，清理失败返回实际错误，不发送 cleaned。

不同 session 同时写相同 user memory 时继续使用已有 runtime 的同步能力；实现阶段核对锁是否跨 runtime 实例共享，若不是，需要按持久化路径统一锁。不能以会话 Engine 隔离代替共享文件的写入协调。

配置在新建 session Engine 时加载并固定。已有 session 的模型与工具配置不因文件修改突然变化；`init --force` 成功后新建的实体读取新配置，已有实体通过关闭及重建更新。重连校验绑定属性，不能悄悄替换已有实体配置。

## 9. 目录与模块依赖

```text
app/fae/src/
├── main.rs
├── app/
│   ├── mod.rs              # CLI 调度
│   ├── args.rs             # 参数、server start/stop/status、默认 agent 解析
│   ├── paths.rs            # home / workspace / 文件路径规范化
│   ├── daemon.rs           # server.config 检查、服务发现、自动拉起、启动锁
│   ├── client.rs           # 控制连接、session 连接、重连、响应分发
│   ├── agent.rs            # 对话命令、TUI 与客户端协调
│   ├── workflow.rs         # workflow 客户端流程
│   └── output.rs           # 非交互输出与退出码
├── server/
│   ├── mod.rs              # 服务入口及监听循环
│   ├── lifecycle.rs        # 服务锁、运行文件发布、信号、shutdown
│   ├── control.rs          # hello / init / status / shutdown
│   ├── connection.rs       # Upgrade、认证、读写与心跳
│   ├── registry.rs         # 会话唯一性、连接 lease、资源回收
│   ├── session.rs          # session actor、回合调度、取消、历史清理
│   ├── replay.rs           # seq、重放缓存、请求去重
│   ├── engine.rs           # EngineBuilder 和 runtime 注册
│   ├── workspace.rs        # WorkspaceHook
│   ├── init.rs             # 配置初始化
│   └── runtime/
│       ├── mod.rs
│       └── python.rs       # PythonActionRuntime
├── tui/
│   ├── mod.rs              # TerminalUi 的公开接口
│   ├── terminal.rs         # raw mode、光标、视口、终端恢复
│   ├── input.rs            # 编辑、键盘、粘贴和运行态操作
│   ├── render.rs           # 消息和状态渲染
│   ├── state.rs            # 纯显示状态
│   ├── file_browser.rs     # 文件选择
│   └── log_capture.rs      # 仅客户端自身日志捕获
└── protocol/
    ├── mod.rs
    ├── control.rs
    ├── session.rs
    └── error.rs
```

依赖方向：`app → protocol/tui`，`server → protocol/fae-agent/fae-engine`，`tui → fae-agent 的显示数据类型`。`tui` 不依赖 `server`、`Engine` 或 `Ctx`，`server` 不依赖 `tui`。

TUI 将当前 `run_session(session, execution, supplement)` 改为消费客户端分发的事件并返回 `Submit/Steer/Cancel/Exit` 等界面动作，由 `app` 执行网络操作。不强行用 `Session` trait 包装所有网络功能，因为 open、取消、重连、清理和 finished 都超出当前 trait 的两个方法。

后台运行日志写入服务日志，不再借 TUI 的 stdout/stderr 捕获转发。用户相关工具结果仍走 `SessionOutput`；跨会话日志不广播给其他 session。保留 TUI 的视口、滚动、颜色、竖杠光标及退出恢复行为。

依赖建议：直接添加 `serde`、`tokio-tungstenite`、`futures-util`；`tokio-tungstenite 0.28` 已在当前锁文件中。使用其 Upgrade 回调验证路由和认证，一期不引入完整 HTTP 框架。跨平台文件锁可选 `fs2`，OS 进程检查和脱离实现封装在生命周期模块；最终版本与平台 API 在实施时核对。

## 10. 错误协议及兼容性

`ProtocolError` 包含 `code`、`message`、`retryable`，必要时附结构化 detail。最少定义：

```text
invalid_message / unsupported_version / unauthorized
invalid_session_id / invalid_workspace / config_not_found
session_in_use / session_binding_conflict / session_busy
round_not_active / unsupported_operation / cleanup_busy
request_id_conflict / resume_gap / resume_expired
resource_exhausted / execution_failed / internal_error
```

可恢复业务错误保留连接，身份校验失败、超大帧和协议无法解析时关闭连接。TUI 使用带 `ERROR` 标签的具体错误消息；非交互模式写 stderr 并以非零退出码结束。模型或工具业务输出失败仍经现有 session 事件传输，最终 outcome 决定成功与失败，不能把连接建立成功作为命令成功。

协议一期版本为 `1`。客户端与服务握手时校验协议；应用版本只用于显示和诊断。未知消息类型返回协议错误；已知消息的未知可选字段可忽略。现有 `SessionEventData::Custom` 扩展事件保持透传。

升级可执行文件后，兼容的已运行服务继续服务，并显示版本信息。不兼容时提示先停止旧服务，再由下一次业务命令拉起新版；不自动中断已有任务。

## 11. 实施顺序

1. **模块拆分**：按目录移动现有功能，保持原执行行为；先明确 app/TUI/server 边界。
2. **共享协议**：定义 envelope、open、输入、输出、finished、错误及控制协议；固定实际 JSON 格式。
3. **服务生命周期**：实现 server start/stop/status、地址和端口参数、server.config、双锁、后台脱离、认证握手、日志和停止逻辑；端口冲突必须使启动失败。
4. **服务会话执行**：迁移 Engine、WorkspaceHook、Python runtime；建立 actor 和唯一事件采集任务，支持 Agent/workflow。
5. **当前回合取消**：在核心提供最小取消接口，接通 cancel 和 finished，处理多回合 Context 归属。
6. **客户端接入**：交互与非交互统一通过 WebSocket；迁移 session 命令、附件路径和初始化。
7. **重连与回收**：接入 lease、seq 重放、请求去重、资源上限和断开后执行。
8. **验证与文档**：完成以下验收，更新 README 和 CLI 帮助。

每个步骤完成后再进入下一步。最终 TUI 和非交互业务路径均不能保留绕过服务的本地 Engine 执行分支。

## 12. 验收与验证

| 范围 | 必须验证的行为 |
| --- | --- |
| 首次启动 | 无 server.config 时自动拉起，默认监听 127.0.0.1:6666，配置包含正确 PID、地址和端口，握手后才进入对话 |
| 显式启动与停止 | fae server start/stop 被正确解析；start 等待就绪，stop 等待服务退出，不递归启动 |
| 自定义监听 | 指定地址和端口准确写入 server.config；后续客户端按该文件连接，不使用硬编码默认端口 |
| 端口冲突 | 占用 6666 或自定义端口后 start 返回非零、报告冲突，不换端口、不发布失败进程配置 |
| 参数和绑定失败 | 拒绝端口 0、超范围端口及非法地址；绑定权限不足、不可用地址有明确错误 |
| 服务复用 | 连续启动多个 fae，后台 PID 不变 |
| 并发启动 | 多客户端同时启动及显式 server start，最终只有一个持锁实例 |
| 状态恢复 | 失效 PID、PID 复用、server.config 缺失或损坏、子进程早退均有确定行为 |
| 常驻 | 前台终端退出后服务及未取消任务继续运行 |
| session 隔离 | 两个 session 两条连接，输出、用户、workspace、历史不串流 |
| 同 session 冲突 | 活连接重复打开、不同 workspace/source 打开均按协议拒绝 |
| 多回合 | 同一连接执行多个回合，mode 可恢复，历史连续保存 |
| 取消 | 第一及第二回合、workflow、委派子 Agent 都取消当前任务，其他 session 不受影响 |
| 终态 | Completed、Failed、Cancelled 竞态下 finished 只发一次；等待不到普通事件也能结束 |
| 清理 | 删除当前历史和共享 todo；相关活动回合存在时返回 cleanup_busy |
| 重连 | 按 seq 补齐，无重复；缓存缺口、实体过期、服务重启不静默重跑 |
| 请求重复 | 同 ID 同内容去重，不同内容报错；未确认写操作不自动重发 |
| 慢客户端 | 队列超限断开连接，执行不挂起，缓存受限 |
| CLI 兼容 | 默认 agent、--workspace、/todo、附件、workflow @input、init、uninstall 正常 |
| TUI 兼容 | 普通及 --no-alt-screen 路径、滚动、ERROR 展示和退出光标恢复 |
| 停止与重启 | 正常清理属于本实例的 server.config；重复 stop 不启动服务，下一次业务命令可启动新实例 |

实现后先执行 `cargo fmt --all -- --check` 和 `cargo check --workspace --all-targets`。针对协议、生命周期、会话竞态执行不依赖真实模型的测试；进程与 WebSocket 验证使用临时 home、独立端口及可控假 runtime，避免修改用户的 `~/.fae`。人工再验证真实 TUI 和模型调用，不能以需要外部凭据的测试替代基础验收。

2026-11-03 实施验证记录：

- `cargo fmt --all -- --check`、`git diff --check`、`cargo check --workspace --all-targets` 均通过。工作区仅保留已有的 async-openai Assistants API 废弃警告。
- `cargo test -p fae -p fae-agent -p fae-engine -- --skip test_model_runtime_exec_chat_completion_bits_ut --skip test_model_runtime_exec_streaming_chat_completion_bits_ut` 通过：fae 50 项、服务进程测试 9 项、fae-agent 90 项、fae-engine 79 项。仅跳过 2 项依赖真实模型的测试。
- 进程测试使用临时 home、独立端口和本地假 SSE 模型，覆盖第二回合及委派取消、workflow 断线续跑/重放、请求去重、认证、容量限制、并发启动、SIGTERM 清理和 50 秒空闲心跳。快速并发测试集连续三轮通过。
- 修复继承父进程信号屏蔽状态导致 SIGTERM/SIGCHLD 无法送达的问题；入口在创建 Tokio worker 前解除服务所需信号屏蔽，信号监听在发布就绪配置前注册。进程测试主动继承屏蔽状态验证这一行为。
- TUI 已与 Engine/Context 执行分离，终端绘图测试通过；真实终端交互、真实模型及 Windows 分支尚未人工或跨平台验证。

该方案的一期边界是本机、单用户 OS 环境中的常驻服务和多 session 并发。跨主机访问、操作系统开机自启、崩溃后恢复正在执行的工具、持久化完整事件流和共享 Engine 池留待独立方案。
