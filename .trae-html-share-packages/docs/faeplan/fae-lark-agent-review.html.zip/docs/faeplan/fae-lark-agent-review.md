结论：发现需要修复的问题，当前实现尚不能判定为正确。cargo check --workspace、58 个 fae 库测试、90 个 fae-agent 库测试、14 个服务集成测试均通过；使用独立 /tmp 配置复现 workflow 间接调用 todo Agent 时 lark check 错误通过。未修改实现，未执行真实飞书发送；平台权限与真实流式行为仍待部署验收。

# 代码评审报告

- 仓库：free-agent-engine
- 检测模式：对照设计审查当前飞书实现
- 检测范围：HEAD 工作区变更 + 11 个未跟踪的新实现文件
- 生成时间：2026-11-08 18:46
- 检查文件：34
- 变更行数：3051

## 缺陷统计

- P0：0
- P1：4
- P2：1
- 合计：5

## 缺陷详情

### 1. [P1][逻辑错误] 恢复时终态查询提前返回，丢弃仍可重放的模型正文

- 位置：`app/fae/src/lark/session.rs:149-170`
- 置信度：10/10

**问题描述**

具体触发：网关在已保存 stream/round、尚未消费全部正文时退出，server 实例继续运行并完成该轮，且未消费事件仍在 replay 缓存内。恢复 Open 使用 record.seq；server/session.rs:523-534 在 Opened 后按序发送完整重放。随后这里先调用 Acceptance；app/client.rs:269-289 会把先到的重放 Event/Finished 放入 pending，但这里只要查询到 outcome 就调用 recover_terminal 并 Close/return，从不调用 next 消费 pending。output.rs:88-127 只能使用本地已见正文及成功 result；失败/取消 outcome 不含正文，因而停机期间的所有可恢复正文直接丢失，成功时也丢失中间响应并可能重复发送最终正文兜底。这不是 resume_gap 或缓存过期场景，违背方案 docs/faeplan/fae-lark-agent.md:381 的重放去重并投递到原 writer 约定。

**修复建议**

终态查询不要替代仍可用的事件重放；先消费并落盘原 stream 的重放直到该 round 的 Finished，只有明确 resume_gap/重放不可用时才用 recover_terminal 兜底，且不要自动重跑 Agent。

---

### 2. [P1][逻辑错误] resume 前重读源配置使已冻结会话无法恢复

- 位置：`app/fae/src/server/mod.rs:124-128`
- 置信度：10/10

**问题描述**

新增 Lark Open 校验无条件执行 config.check_agent，未区分新建与 resume。该函数在 lark/config.rs:127创建全新 builder、134-136重新读取 Agent 配置及 prompt；builder.rs:77-105直接从文件读取。具体触发路径：合法 Lark 会话已建立并启动 round，随后删除其源 prompt/config 文件，连接断开后 Client::reconnect在app/client.rs:350-356携带原 binding/stream/session 恢复；此处 check_agent 因文件不存在返回错误，mod.rs:137-140发送 invalid_binding，根本不会进入 registry.open 的已有 actor 恢复路径。registry.rs:218-219明确约定已有绑定在源文件删除或 init --force 后仍用固定配置，318-326也已在创建时 freeze_source。结果是原任务仍可继续执行，网关却在重连失败后报告失败，无法收到后续事件和 Finished。这是本次新增前置检查破坏已有冻结/resume语义，不是跨用户恢复问题。

**修复建议**

新 actor 创建时检查源配置和隔离能力；resume 在校验认证、允许的身份域及完整绑定后，使用已有 actor 的冻结配置/能力证明进行恢复，不重新依赖源配置或 prompt 文件。

---

### 3. [P1][业务语义问题] Workflow 间接调用的 Agent 可绕过 Todo 隔离检查

- 位置：`app/fae/src/lark/config.rs:142-149`
- 置信度：9/10

**问题描述**

check_agent 仅递归 config.sub_agents，对 workflow 只搜索当前 JSON 中是否出现字符串 "todo"，没有遍历 single_agent.source 和嵌套 workflow。父 Agent 无 todo、声明 delegate workflow；delegate 的 single_agent 节点引用 tools=[todo] 的 worker 时，检查仍通过。已经使用独立 /tmp 配置执行 cargo run -q -p fae -- --fae-home <fixture> lark check，退出码 0 并显示 Lark configuration valid。运行时 WorkflowAction::SingleAgent 会加载 worker。当前 Todo 的无 plan scope 查询会枚举整个 agent/user 的计划，未按 session 过滤，因此可把同用户其他会话的待办带入当前群聊；无 ownership 的变更则返回 400，并非覆盖其他计划。违反设计要求的启动拒绝策略。

**修复建议**

按类型解析 WorkflowMetadata，递归遍历 SingleAgent 来源和嵌套 Workflow 引用，维护 visited 集避免循环；对动态/无法静态证明隔离的执行入口拒绝启动，或在执行时统一落实 scope 级工具状态隔离。

---

### 4. [P1][并发问题] 停止超时后 outbox 未终止，清理流程会并发写同一卡片

- 位置：`app/fae/src/lark/mod.rs:182-192`
- 置信度：9/10

**问题描述**

timeout 接收 owned JoinHandle，超过 10 秒时只丢弃 handle，并不会 abort 后台任务。outbox 正在网络重试、等待 Retry-After，或执行多条记录的最后投递 pass 时可超过此期限；主流程随即为相同 pending 记录创建第二个 Writer 并 flush。两条异步执行都可读取相同 pending/sequence、在一方推进后重建相同序号的不同更新，或重复创建/reply 卡片，破坏单 writer 和严格递增序号契约。此外每条记录各给 2 秒而没有全局截止时间，足够多失败记录会超过 lark stop 的 30 秒期限。

**修复建议**

用可借用的 JoinHandle 等待；超时后 abort 并 await 确认任务退出，再启动最终投递；最终清理设置整个 shutdown 的统一预算，剩余投递保持落盘待下次恢复。

---

### 5. [P2][业务语义问题] 明确未启动的请求被误报为接受状态不确定

- 位置：`app/fae/src/server/session.rs:335-343`
- 置信度：10/10

**问题描述**

ExternalInput 先写 round_id=null、uncertain=true 的 intent，再调用 start。服务达到 8 个活动 round 上限、正在清理或 session 忙碌时，reserve_round 会在启动任务前明确拒绝；此处直接返回错误，未撤销 intent 或记录确定拒绝。当前网关随后查询 Acceptance，把已确定未启动的请求提示为接受状态不确定。网关本轮会报错收尾，用户重新发送消息可使用新 ID，所以不会永久阻断当前网关后续消息；但原 ID 的接受记录始终不准确，也无法区分资源拒绝与真正的崩溃不确定窗口。

**修复建议**

在持久化 intent 前原子预留 round 名额，或在确认 start 未启动任务的失败路径撤销 intent/记录明确拒绝状态；仅对真正无法证明是否启动的路径保留 uncertain，允许确定未启动的请求在资源恢复后用原 ID 重试。

---


### 恢复时终态查询提前返回，丢弃仍可重放的模型正文

[app/fae/src/lark/session.rs](file:///Users/bytedance/project/work/github/free-agent-engine/app/fae/src/lark/session.rs#L149-L170)

```rust
 149:         if recovering {
 150:             if let ServerMessage::Acceptance {
 151:                 outcome: Some(outcome),
 152:                 ..
 153:             } = client
 154:                 .request(ClientMessage::Acceptance {
 155:                     external_request_id: record.id.clone(),
 156:                 })
 157:                 .await?
 158:             {
 159:                 self.store.update(id, |r| {
 160:                     output::recover_terminal(r, &round_id, outcome);
 161:                     if let Some(notice) = &r.notice {
 162:                         r.notice = Some(self.sdk.sanitize(notice));
 163:                     }
 164:                 })?;
 165:                 let _ = client
 166:                     .request(ClientMessage::Close {
 167:                         cancel_active: false,
 168:                     })
 169:                     .await;
 170:                 return Ok(());
```


### resume 前重读源配置使已冻结会话无法恢复

[app/fae/src/server/mod.rs](file:///Users/bytedance/project/work/github/free-agent-engine/app/fae/src/server/mod.rs#L124-L128)

```rust
 124:                             let validation = if route == "/v2/lark/session" {
 125:                                 match crate::lark::config::Config::load(&registry.home) {
 126:                                     Ok(config) => match config.check_agent(&registry.home).await {
 127:                                         Ok(()) => crate::lark::identity::validate(&config, &open),
 128:                                         Err(error) => Err(error),
```


### Workflow 间接调用的 Agent 可绕过 Todo 隔离检查

[app/fae/src/lark/config.rs](file:///Users/bytedance/project/work/github/free-agent-engine/app/fae/src/lark/config.rs#L142-L149)

```rust
 142:             for workflow in config.workflows {
 143:                 let value: serde_json::Value = serde_json::from_slice(&std::fs::read(
 144:                     home.join("workflows").join(format!("{workflow}.json")),
 145:                 )?)?;
 146:                 anyhow::ensure!(
 147:                     !value.to_string().contains("\"todo\""),
 148:                     "Lark workflow `{workflow}` exposes shared todo state"
 149:                 );
```


### 停止超时后 outbox 未终止，清理流程会并发写同一卡片

[app/fae/src/lark/mod.rs](file:///Users/bytedance/project/work/github/free-agent-engine/app/fae/src/lark/mod.rs#L182-L192)

```rust
 182:     let _ = tokio::time::timeout(Duration::from_secs(10), router).await;
 183:     let _ = tokio::time::timeout(Duration::from_secs(10), outbox).await;
 184:     for record in store.pending() {
 185:         if record.outcome.is_none() {
 186:             gateway.fail(&record.id, "网关停止，本次执行已取消");
 187:         }
 188:         let writer = card::Writer {
 189:             sdk: sdk.clone(),
 190:             store: store.clone(),
 191:         };
 192:         let _ = tokio::time::timeout(Duration::from_secs(2), writer.flush(&record.id)).await;
```


### 明确未启动的请求被误报为接受状态不确定

[app/fae/src/server/session.rs](file:///Users/bytedance/project/work/github/free-agent-engine/app/fae/src/server/session.rs#L335-L343)

```rust
 335:                 super::acceptance::write(
 336:                     &self.registry.home,
 337:                     &external_request_id,
 338:                     &self.key,
 339:                     digest.clone(),
 340:                     None,
 341:                     true,
 342:                 )?;
 343:                 let round = self.start(Some((data, None))).await?;
```
